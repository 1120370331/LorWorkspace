using LOR_DiceSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Steria; // For CardAbilityHelper and SteriaLogger

// --- Dice Card Abilities (Effects on Dice) ---

#region 拙劣控流 (ID: 9001001) Dice 1
public class DiceCardAbility_AnhierFlow1 : DiceCardAbilityBase
{
    public static string Desc = "[命中时] 获得1层[流]";
    public override string[] Keywords => new string[] { "SteriaFlow" };
    public override void OnSucceedAttack()
    {
        CardAbilityHelper.AddFlowStacks(this.owner, 1);
    }
}
#endregion

// 珍贵的回忆 (ID: 9001006) On Use
// 主要效果在 Harmony 补丁的弃牌逻辑里处理，这里保持脚本存在以匹配 XML
public class DiceCardSelfAbility_AnhierPreciousDiscard : DiceCardSelfAbilityBase
{
    public static string Desc = "[佚亡][被弃置时] 摧毁本书页，并抽取2张书页并在下一幕获得1层[强壮]";
    // 不需要在 OnUseCard 里做额外处理，弃置效果由 Harmony 补丁统一监听
}

#region 回忆侧斩 (ID: 9001002) Dice 1
public class DiceCardAbility_AnhierDraw1 : DiceCardAbilityBase
{
    public static string Desc = "[命中时] 抽取1张书页";
    public override void OnSucceedAttack()
    {
        SteriaLogger.Log($"[AnhierDraw1] OnSucceedAttack triggered! Owner={this.owner?.UnitData?.unitData?.name}");
        this.owner.allyCardDetail.DrawCards(1);
        SteriaLogger.Log($"[AnhierDraw1] DrawCards(1) called");
    }
}
#endregion

#region 奥塔尔的荣耀 (ID: 9001003) Dice 1 & 2
public class DiceCardAbility_AnhierGainLight1 : DiceCardAbilityBase
{
    public static string Desc = "[命中时] 恢复1点光芒";
    public override void OnSucceedAttack()
    {
        this.owner.cardSlotDetail.RecoverPlayPoint(1);
    }
}

public class DiceCardAbility_AnhierClashWinDraw1 : DiceCardAbilityBase
{
    public static string Desc = "[拼点胜利] 抽取1张书页";
    public override void OnWinParrying()
    {
        this.owner.allyCardDetail.DrawCards(1);
    }
}

public class DiceCardAbility_AnhierClashWinGainLight1 : DiceCardAbilityBase
{
    public static string Desc = "[拼点胜利] 恢复1点光芒";
    public override void OnWinParrying()
    {
        this.owner.cardSlotDetail.RecoverPlayPoint(1);
    }
}

public class DiceCardAbility_AnhierGainLight2 : DiceCardAbilityBase
{
    public static string Desc = "[命中时] 恢复2点光芒";
    public override void OnSucceedAttack()
    {
        this.owner.cardSlotDetail.RecoverPlayPoint(2);
    }
}
#endregion

#region 攫取回忆 (ID: 9001005) Dice 1 & 2
public class DiceCardAbility_AnhierGrabDraw1 : DiceCardAbilityBase
{
    public static string Desc = "[命中时] 抽取1张书页";
    public override void OnSucceedAttack()
    {
        this.owner.allyCardDetail.DrawCards(1);
    }
}
#endregion

#region 以执为攻 (ID: 9001009) Dice 2
public class DiceCardAbility_AnhierBindingNextTurn : DiceCardAbilityBase
{
    public static string Desc = "[命中时] 下回合使其获得1层[束缚]";
    public override void OnSucceedAttack()
    {
        BattleUnitModel target = this.card?.target;
        if (target != null && !target.IsDead())
        {
            // AddKeywordBufByEtc 默认下一幕生效，直接赋予即可
            target.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Binding, 1, this.owner);
            SteriaLogger.Log($"以执为攻: Applied 1 Binding to {target.UnitData?.unitData?.name}");
        }
    }
}
#endregion


// --- Self Card Abilities (Effects On Use) ---

#region 拙劣控流 (ID: 9001001) On Use
public class DiceCardSelfAbility_AnhierRecoverLight1 : DiceCardSelfAbilityBase
{
    public static string Desc = "[流转] [使用时] 恢复1点光芒";

    public override string[] Keywords => new string[] { "SteriaFlowTransfer" };

    public override void OnUseCard()
    {
        this.owner.cardSlotDetail.RecoverPlayPoint(1);
    }
}
#endregion

#region 回忆侧斩 (ID: 9001002) On Use
public class DiceCardSelfAbility_AnhierDiscardRandom1 : DiceCardSelfAbilityBase
{
    public static string Desc = "[使用时] 从手中随机丢弃1张书页";
    public override void OnUseCard()
    {
        this.owner.allyCardDetail.DisCardACardRandom();
    }
}
#endregion

#region 奥塔尔的荣耀 (ID: 9001003) On Use
public class DiceCardSelfAbility_AnhierDiscardAllDraw : DiceCardSelfAbilityBase
{
    public static string Desc = "[使用时] 丢弃2张手牌来使本书页骰子威力+1";

    public override void OnUseCard()
    {
        List<BattleDiceCardModel> hand = this.owner.allyCardDetail.GetHand();
        int discardedCount = 0;
        int maxDiscard = Math.Min(2, hand.Count);

        // 丢弃最多2张手牌
        for (int i = 0; i < maxDiscard; i++)
        {
            if (hand.Count > 0)
            {
                this.owner.allyCardDetail.DisCardACardRandom();
                discardedCount++;
            }
        }

        // 每丢弃2张牌，骰子威力+1
        int powerBonus = discardedCount / 2;
        if (powerBonus > 0)
        {
            foreach (BattleDiceBehavior behavior in this.card.GetDiceBehaviorList())
            {
                behavior.ApplyDiceStatBonus(new DiceStatBonus { power = powerBonus });
            }
            SteriaLogger.Log($"奥塔尔的荣耀: Discarded {discardedCount} cards, power bonus +{powerBonus}");
        }
    }

    // 被丢弃时：抽1张书页
    public override void OnDiscard(BattleUnitModel unit, BattleDiceCardModel self)
    {
        unit?.allyCardDetail?.DrawCards(1);
        SteriaLogger.Log("奥塔尔的荣耀: OnDiscard - Drew 1 card");
    }
}
#endregion

#region 回忆协奏之刃 (ID: 9001004) On Use
public class DiceCardSelfAbility_AnhierDiscardAllPowerUp : DiceCardSelfAbilityBase
{
    public static string Desc = "[使用时] 丢弃手中所有书页，并使本书页所有骰子威力+{0}";

    public override void OnUseCard()
    {
        List<BattleDiceCardModel> hand = this.owner.allyCardDetail.GetHand();
        int discardedCount = 0;
        List<BattleDiceCardModel> handClone = new List<BattleDiceCardModel>(hand);
        foreach (BattleDiceCardModel cardToDiscard in handClone)
        {
            if (cardToDiscard == this.card.card) continue;
            this.owner.allyCardDetail.DiscardACardByAbility(cardToDiscard);
            discardedCount++;
        }

        int powerBonus = discardedCount;
        if (powerBonus > 0)
        {
            foreach (BattleDiceBehavior behavior in this.card.GetDiceBehaviorList())
            {
                behavior.ApplyDiceStatBonus(new DiceStatBonus { power = powerBonus });
            }
        }
    }
}
#endregion

#region 内调之流 (ID: 9001007) On Use
public class DiceCardSelfAbility_AnhierGainFlow5Draw2NextTurn : DiceCardSelfAbilityBase
{
    public static string Desc = "[流转] [使用时] 抽取2张书页，下回合获得3层[流]"; // 削弱：5→3

    public override string[] Keywords => new string[] { "SteriaFlowTransfer", "SteriaFlow" };

    public override void OnUseCard()
    {
        SteriaLogger.Log("内调之流: OnUseCard triggered - Drawing 2 cards and adding flow buff");
        this.owner.allyCardDetail.DrawCards(2);
        this.owner.bufListDetail.AddBuf(new BattleUnitBuf_AddFlowNextRound { amount = 3 }); // 削弱：5→3
    }
}

public class BattleUnitBuf_AddFlowNextRound : BattleUnitBuf
{
    public int amount = 0;

    public override void Init(BattleUnitModel owner)
    {
        base.Init(owner);
        SteriaLogger.Log($"BattleUnitBuf_AddFlowNextRound: Init called, amount={amount}");
    }

    public override void OnRoundStart()
    {
        SteriaLogger.Log($"BattleUnitBuf_AddFlowNextRound: OnRoundStart called, amount={amount}");
        if (this._owner != null && amount > 0)
        {
            CardAbilityHelper.AddFlowStacks(this._owner, amount);
            SteriaLogger.Log($"BattleUnitBuf_AddFlowNextRound: Added {amount} flow stacks");
        }
        this.Destroy();
    }
}
#endregion

#region 清司风流 (ID: 9001008) On Use
// 特殊效果：流转（通过Harmony补丁实现，下回合返还本书页实际消耗的流）
public class DiceCardSelfAbility_AnhierQingSiFengLiu : DiceCardSelfAbilityBase
{
    public static string Desc = "[流转]";

    public override string[] Keywords => new string[] { "SteriaFlowTransfer" };

    // 无使用时效果，仅有流转被动
}
#endregion

#region 清司风流 (ID: 9001008) Dice 1
// 命中时：若自身流层数>=10则重新投掷本骰子并使流层数-10（可重复触发）
public class DiceCardAbility_AnhierQingSiFengLiuDice1 : DiceCardAbilityBase
{
    public static string Desc = "[命中时] 若自身[流]层数>=10，则重新投掷本骰子并使[流]层数-10（可重复触发）";
    public override string[] Keywords => new string[] { "SteriaFlow" };

    public override void OnSucceedAttack(BattleUnitModel target)
    {
        SteriaLogger.Log("清司风流 Dice1: OnSucceedAttack triggered");

        // 直接创建特效和播放音效
        try
        {
            // 播放音效
            Sound.SoundEffectPlayer.PlaySound("Battle/Kali_Atk");

            // 创建特效
            if (this.owner?.view != null && target?.view != null)
            {
                SingletonBehavior<DiceEffectManager>.Instance?.CreateBehaviourEffect(
                    "Kali_Z", 1f, this.owner.view, target.view, 1f);
            }

            // 屏幕震动
            SteriaEffectHelper.AddScreenShake(0.02f, 0.01f, 70f, 0.3f);
        }
        catch (System.Exception ex)
        {
            SteriaLogger.Log($"清司风流 effect error: {ex.Message}");
        }

        // 获取当前流的层数
        BattleUnitBuf_Flow flowBuf = this.owner.bufListDetail.GetActivatedBufList()
            .FirstOrDefault(b => b is BattleUnitBuf_Flow) as BattleUnitBuf_Flow;

        int flowStacks = flowBuf?.stack ?? 0;
        SteriaLogger.Log($"清司风流 Dice1: Current flow stacks = {flowStacks}");

        if (flowStacks >= 10)
        {
            bool hasProxy = DirectiveDreamHelper.HasStephanieProxy(this.owner);

            // 消耗10层流
            if (!hasProxy)
            {
                flowBuf.stack -= 10;
                SteriaLogger.Log($"清司风流 Dice1: Consumed 10 flow, remaining = {flowBuf.stack}");

                if (flowBuf.stack <= 0)
                {
                    flowBuf.Destroy();
                }
            }

            // 通知被动流被消耗
            HarmonyHelpers.NotifyPassivesOnFlowConsumed(this.owner, 10);

            // 使用游戏内置方法触发骰子重复攻击
            SteriaLogger.Log("清司风流 Dice1: Activating bonus attack dice (re-roll)");
            ActivateBonusAttackDice();
        }
    }
}
#endregion

#region 以执为攻 (ID: 9001009) On Use
// 本舞台中，每弃置4张书页便使本书页骰子威力+1（按角色独立计数）
public class DiceCardSelfAbility_AnhierDiscardPowerUp : DiceCardSelfAbilityBase
{
    public static string Desc = "本舞台中，每弃置4张书页便使本书页骰子威力+1";

    // 按角色存储弃牌计数
    private static Dictionary<BattleUnitModel, int> _discardCountPerUnit = new Dictionary<BattleUnitModel, int>();

    public static void IncrementDiscardCount(BattleUnitModel unit)
    {
        if (unit == null) return;
        if (!_discardCountPerUnit.ContainsKey(unit))
            _discardCountPerUnit[unit] = 0;
        _discardCountPerUnit[unit]++;
        SteriaLogger.Log($"以执为攻: {unit.UnitData?.unitData?.name} discard count incremented to {_discardCountPerUnit[unit]}");
    }

    public static void ResetAllDiscardCounts()
    {
        _discardCountPerUnit.Clear();
        SteriaLogger.Log("以执为攻: All discard counts reset");
    }

    public static int GetDiscardCount(BattleUnitModel unit)
    {
        if (unit == null) return 0;
        _discardCountPerUnit.TryGetValue(unit, out int count);
        return count;
    }

    public override void OnUseCard()
    {
        int discardCount = GetDiscardCount(this.owner);
        int powerBonus = discardCount / 4;
        SteriaLogger.Log($"以执为攻: OnUseCard - {this.owner?.UnitData?.unitData?.name} discards: {discardCount}, Power bonus: +{powerBonus}");

        if (powerBonus > 0)
        {
            foreach (BattleDiceBehavior behavior in this.card.GetDiceBehaviorList())
            {
                behavior.ApplyDiceStatBonus(new DiceStatBonus { power = powerBonus });
            }
        }
    }
}
#endregion

#region 寒地后勤 (ID: 9001010) On Use & On Discard
public class DiceCardSelfAbility_AnhierColdLogistics : DiceCardSelfAbilityBase
{
    public static string Desc = "[使用时] 恢复2点光芒\n[被弃置时] 恢复2点光芒";

    // 使用时：恢复2点光芒
    public override void OnUseCard()
    {
        this.owner.cardSlotDetail.RecoverPlayPoint(2);
        SteriaLogger.Log($"寒地后勤: OnUseCard - Recovered 2 light for {this.owner?.UnitData?.unitData?.name}");
    }

    // 被丢弃时：恢复2点光芒
    public override void OnDiscard(BattleUnitModel unit, BattleDiceCardModel self)
    {
        if (unit != null)
        {
            unit.cardSlotDetail.RecoverPlayPoint(2);
            SteriaLogger.Log($"寒地后勤: OnDiscard - Recovered 2 light for {unit.UnitData?.unitData?.name}");
        }
    }
}
#endregion

#region 自我之流 (ID: 9001011) EGO装备
// EGO装备（Instance类型）：装备时扣除12点生命值，获得5层流
// 冷却时间：4幕（使用Steria自定义冷却系统）
public class DiceCardSelfAbility_AnhierSelfFlow : DiceCardSelfAbilityBase
{
    public static string Desc = "[装备时] 扣除12点生命值，立即获得5层[流]；冷却时间：4幕";
    public override string[] Keywords => new string[] { "SteriaFlow" };

    // 卡牌ID
    public const int CARD_ID = 9001011;
    // 冷却时间常量
    public const int COOLDOWN_ROUNDS = 4;

    // Instance类型卡牌使用OnUseInstance而不是OnUseCard
    public override void OnUseInstance(BattleUnitModel unit, BattleDiceCardModel self, BattleUnitModel targetUnit)
    {
        SteriaLogger.Log($"自我之流: OnUseInstance triggered for {unit?.UnitData?.unitData?.name}");

        // 检查自定义冷却
        if (Steria.SteriaEgoCooldownManager.IsOnCooldown(unit, CARD_ID))
        {
            int remaining = Steria.SteriaEgoCooldownManager.GetRemainingCooldown(unit, CARD_ID);
            SteriaLogger.Log($"自我之流: On cooldown, {remaining} rounds remaining");
            return;
        }

        int damage = 12;

        // 播放受击音效 (H = Hit)
        try
        {
            unit.view?.charAppearance?.soundInfo?.PlaySound(LOR_DiceSystem.MotionDetail.H, true);
        }
        catch (Exception ex)
        {
            SteriaLogger.Log($"自我之流: Sound error: {ex.Message}");
        }

        // 播放水系环绕特效
        try
        {
            SingletonBehavior<DiceEffectManager>.Instance?.CreateBehaviourEffect(
                "Steria_WaterSurround", 1f, unit.view, unit.view, 1.2f);
        }
        catch (Exception ex)
        {
            SteriaLogger.Log($"自我之流: Effect error: {ex.Message}");
        }

        // 显示伤害数字
        try
        {
            SingletonBehavior<AttackEffectManager>.Instance?.CreateDamagedTextEffect(
                damage, BehaviourDetail.Hit, unit, unit, AtkResist.Normal, false, 1);
        }
        catch (Exception ex)
        {
            SteriaLogger.Log($"自我之流: DamageText error: {ex.Message}");
        }

        // 扣除生命值
        unit.SetHp((int)(unit.hp - damage));
        SteriaLogger.Log($"自我之流: Lost {damage} HP, current HP: {unit.hp}");

        // 自我之流是即时装备效果，保留本幕可用流；其他产流仍走下幕结算。
        CardAbilityHelper.AddFlowStacksThisRound(unit, 5);
        SteriaLogger.Log($"自我之流: Granted 5 base Flow immediately (source multiplier applies once)");

        // 设置自定义冷却
        Steria.SteriaEgoCooldownManager.StartCooldown(unit, CARD_ID);
    }
}
#endregion

#region 忘却之梦 (ID: 9001012) - 安希尔EGO
/// <summary>
/// 忘却之梦 - 使用时效果
/// [使用时] 下回合使自身陷入混乱
/// </summary>
public class DiceCardSelfAbility_AnhierForgottenDream : DiceCardSelfAbilityBase
{
    private const string MOD_ID = "SteriaBuilding";
    private const int FORGOTTEN_DREAM_CARD_ID = 9001012;

    public static string Desc = "[使用时] 下回合使自身陷入混乱";

    public override void OnUseCard()
    {
        // 下回合使自身陷入混乱
        if (this.owner != null)
        {
            // 添加一个buff，在回合结束时触发混乱
            this.owner.bufListDetail.AddBuf(new BattleUnitBuf_ForgottenDreamStagger());
            SteriaLogger.Log("忘却之梦: 下回合将陷入混乱");

            // 从EGO装备区移除此卡牌（消耗）
            LorId cardId = new LorId(MOD_ID, FORGOTTEN_DREAM_CARD_ID);
            this.owner.personalEgoDetail.RemoveCard(cardId);
            SteriaLogger.Log("忘却之梦: 已从EGO装备区移除");
        }

        // 应用弃牌威力加成（每丢弃2张+1威力）
        int discardCount = DiceCardSelfAbility_AnhierDiscardPowerUp.GetDiscardCount(this.owner);
        int discardBonus = discardCount / 2;
        if (discardBonus > 0)
        {
            foreach (BattleDiceBehavior behavior in this.card.GetDiceBehaviorList())
            {
                behavior.ApplyDiceStatBonus(new DiceStatBonus { power = discardBonus });
            }
            SteriaLogger.Log($"忘却之梦: 弃牌威力加成 +{discardBonus}（已弃{discardCount}张）");
        }
    }
}

/// <summary>
/// 忘却之梦骰子1 - 命中时追加打击伤害
/// [命中时] 对敌人追加"本舞台本角色已消耗流"点打击伤害
/// </summary>
public class DiceCardAbility_AnhierForgottenDreamDice1 : DiceCardAbilityBase
{
    public static string Desc = "[命中时] 对敌人追加打击伤害（每消耗2层流+1伤害）";

    public override void OnSucceedAttack(BattleUnitModel target)
    {
        if (target == null || this.owner == null) return;

        // 获取本舞台已消耗的流总数，每2层+1伤害
        int flowConsumed = PassiveAbility_9000005.GetTotalFlowConsumedThisStage(this.owner);
        int flowDamage = flowConsumed / 2;

        if (flowDamage > 0)
        {
            // 获取目标对打击的抗性
            AtkResist hitResist = target.GetResistHP(BehaviourDetail.Hit);
            float resistRate = BookModel.GetResistRate(hitResist);

            // 计算实际伤害（应用抗性）
            int actualDamage = (int)(flowDamage * resistRate);
            if (actualDamage < 1) actualDamage = 0;

            // 造成伤害
            target.TakeDamage(actualDamage, DamageType.Card_Ability, this.owner, KeywordBuf.None);

            // 显示伤害数字（带抗性显示）
            if (actualDamage > 0)
            {
                SingletonBehavior<AttackEffectManager>.Instance?.CreateDamagedTextEffect(
                    actualDamage, BehaviourDetail.Hit, target, this.owner, hitResist, true, 1);
            }

            SteriaLogger.Log($"忘却之梦: 追加 {actualDamage} 点打击伤害（基础{flowDamage}，抗性{hitResist}={resistRate}，已消耗{flowConsumed}层流）");
        }
    }
}

/// <summary>
/// 忘却之梦 - 下回合混乱Buff
/// </summary>
public class BattleUnitBuf_ForgottenDreamStagger : BattleUnitBuf
{
    public override BufPositiveType positiveType => BufPositiveType.Negative;

    public override void OnRoundEnd()
    {
        if (_owner != null && !_owner.IsDead())
        {
            // 在回合结束时使自身陷入混乱，这样下回合会眩晕恢复
            _owner.breakDetail.TakeBreakDamage(9999, DamageType.Buf, null, AtkResist.Normal);
            SteriaLogger.Log("忘却之梦: 陷入混乱");
        }
        this.Destroy();
    }
}
#endregion
