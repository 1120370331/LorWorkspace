using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq; // Required for Linq
using LOR_DiceSystem; // Required for DiceStatBonus etc.
using BaseMod; // Required for PassiveAbilityBase and potentially Tools
using UnityEngine; // Required for Debug.Log and Singleton
using System.Reflection;

namespace Steria
{
    // --- Moved Harmony Helper Methods and Storage Here ---
    public static partial class HarmonyHelpers // Renamed from partial HarmonyPatches to avoid confusion
    {
        // Simple class to hold flow consumption data for a card instance during its action
        internal class FlowCardData
        {
            public bool ShouldConsumeFlow { get; set; } = false; // Does this card type consume flow?
            public int InitialFlowAvailable { get; set; } = 0; // How much flow was available *when the card was used*?
            public int CurrentFlowRemaining { get; set; } = 0; // How much flow is left for subsequent dice *in this action*?
        }

        // Storage for flow consumption *rules* per card instance (determined at card use start)
        internal static Dictionary<BattlePlayingCardDataInUnitModel, FlowCardData> _flowConsumingCards = new Dictionary<BattlePlayingCardDataInUnitModel, FlowCardData>();

        // Storage for flow consumed per card instance during an action
        internal static Dictionary<BattlePlayingCardDataInUnitModel, int> _flowConsumedByCardAction = new Dictionary<BattlePlayingCardDataInUnitModel, int>();
        // Storage for flow consumed per dice behavior instance during an action
        internal static Dictionary<BattleDiceBehavior, int> _flowConsumedByDiceAction = new Dictionary<BattleDiceBehavior, int>();
        // Storage for dice behaviors that triggered a repeat effect this action
        internal static HashSet<BattleDiceBehavior> _repeatTriggeredDice = new HashSet<BattleDiceBehavior>();

        private static int _tideEnhancementSuppressionDepth;

        public static bool IsTideEnhancementSuppressed => _tideEnhancementSuppressionDepth > 0;

        public static void RunWithoutTideEnhancement(Action action)
        {
            if (action == null)
            {
                return;
            }

            _tideEnhancementSuppressionDepth++;
            try
            {
                action();
            }
            finally
            {
                _tideEnhancementSuppressionDepth = Math.Max(0, _tideEnhancementSuppressionDepth - 1);
            }
        }

        public static int GetFlowConsumedByCard(BattlePlayingCardDataInUnitModel card) {
            // Manual implementation of GetValueOrDefault
            _flowConsumedByCardAction.TryGetValue(card, out int consumed);
            return consumed; // Returns 0 if key not found
        }

        public static int GetFlowConsumedByDice(DiceCardAbilityBase ability) {
            // Assuming 'ability.behavior' IS set by the game when calling ability methods:
            // Ensure ability and behavior are not null before accessing
            BattleDiceBehavior currentBehavior = ability?.behavior;
            if (currentBehavior != null) {
                 // Manual implementation of GetValueOrDefault
                 if (!_flowConsumedByDiceAction.TryGetValue(currentBehavior, out int consumed))
                     consumed = GetFlowEnhancementCountForDice(currentBehavior.card, currentBehavior.Index);
                 return consumed;
            } else {
                 // Reduced log spam: Only log warning if ability itself wasn't null
                 if (ability != null) {
                     Debug.LogWarning($"[MyDLL] HarmonyHelpers.GetFlowConsumedByDice: Could not find behavior for ability {ability.GetType().Name}. This method might not work reliably.");
                 }
                 return 0; // Cannot determine consumption without behavior instance
            }
        }

         // Method to record consumption (called from patches)
         public static void RecordFlowConsumptionForCard(BattlePlayingCardDataInUnitModel card, int amount) {
                if (card != null) {
                     // Manual implementation of GetValueOrDefault + update
                     _flowConsumedByCardAction.TryGetValue(card, out int current);
                     _flowConsumedByCardAction[card] = current + amount;
                     Debug.Log($"[MyDLL] Recorded {amount} flow consumption for card {card.card.GetName()}. Total this action: {_flowConsumedByCardAction[card]}");
                }
         }
         // Method to record consumption (called from patches) - Added index parameter
         public static void RecordFlowConsumptionForDice(BattleDiceBehavior behavior, int index, int amount) { // Added index parameter
             if (behavior != null) {
                  // Manual implementation of GetValueOrDefault + update
                  _flowConsumedByDiceAction.TryGetValue(behavior, out int current);
                  _flowConsumedByDiceAction[behavior] = current + amount;
                  // Use the passed-in index for logging
                  Debug.Log($"[MyDLL] Recorded {amount} flow consumption for dice behavior (Index: {index}). Total this action: {_flowConsumedByDiceAction[behavior]}");
             }
         }
         public static void ClearFlowConsumptionTracking() { // Call this at appropriate times (e.g., end of action/round start)
                _flowConsumedByCardAction.Clear();
                _flowConsumedByDiceAction.Clear();
                _flowConsumingCards.Clear(); // Also clear the rules dictionary
                _repeatTriggeredDice.Clear(); // Clear the repeat set as well
                // 重置"本幕不消耗流"标志
                HarmonyPatches.NoFlowConsumptionActiveThisRound = false;
                Debug.Log("[MyDLL] Cleared Flow Consumption Tracking dictionaries (including repeat set and NoFlowConsumption flag).");
         }

        // 存储每颗骰子的威力加成（由流分配）- 使用卡牌实例+骰子索引作为键
        private static Dictionary<BattlePlayingCardDataInUnitModel, Dictionary<int, int>> _flowPowerBonusPerCard =
            new Dictionary<BattlePlayingCardDataInUnitModel, Dictionary<int, int>>();

        // 存储已经应用了流加成的骰子实例（用于防止重复应用，同时允许反击骰子获得加成）
        private static HashSet<BattleDiceBehavior> _flowBonusAppliedDice = new HashSet<BattleDiceBehavior>();
        // 存储已应用潮之启示加成的骰子实例
        private static HashSet<BattleDiceBehavior> _tideRevelationAppliedDice = new HashSet<BattleDiceBehavior>();

        // 检查骰子是否已经应用了流加成
        public static bool HasFlowBonusApplied(BattleDiceBehavior dice)
        {
            return dice != null && _flowBonusAppliedDice.Contains(dice);
        }

        // 标记骰子已经应用了流加成
        public static void MarkFlowBonusApplied(BattleDiceBehavior dice)
        {
            if (dice != null)
            {
                _flowBonusAppliedDice.Add(dice);
            }
        }

        // 清除已应用流加成的骰子记录
        public static void ClearFlowBonusAppliedDice()
        {
            _flowBonusAppliedDice.Clear();
        }

        public static bool HasTideRevelationApplied(BattleDiceBehavior dice)
        {
            return dice != null && _tideRevelationAppliedDice.Contains(dice);
        }

        public static void MarkTideRevelationApplied(BattleDiceBehavior dice)
        {
            if (dice != null)
            {
                _tideRevelationAppliedDice.Add(dice);
            }
        }

        public static void RemoveTideRevelationApplied(BattleDiceBehavior dice)
        {
            if (dice != null)
            {
                _tideRevelationAppliedDice.Remove(dice);
            }
        }

        private const string _flowTransferKeywordId = "SteriaFlowTransfer";
        private const string _phantomDreamKeywordId = "SteriaPhantomDream";

        // 流转卡牌ID集合：正常消耗流获得加成，并在下回合开始时返还实际消耗的流
        // 添加新卡牌时只需在此集合中添加对应ID即可
        private static readonly HashSet<int> _flowTransferCardIds = new HashSet<int>
        {
            9001001,  // 拙劣控流
            9001007,  // 内调之流
            9001008,  // 清司风流
            // 斯拉泽雅流转卡牌
            9002001,  // 逐梦随流
            9002002,  // 川流不息
            9002003,  // 万物之流
            // 司流者教徒流转卡牌
            9003005,  // 顺流而为
            // 艾莉蕾尔流转卡牌
            9007001,  // 暮雾伏击
            9007002,  // 侧闪
            // 克丽丝塔夏流转卡牌
            9010009,  // 随流而来，伴流而去
            9010010,  // 深渊之中，太阳升起
            // 安蒂司流形态
            9011401,  // 塑海
            9011402,  // 逆流
            // 在此添加更多具有相同效果的卡牌ID...
        };

        // 消耗所有流但不提供威力加成的卡牌ID集合（群攻卡牌等）
        private static readonly HashSet<int> _consumeAllFlowNoBonus = new HashSet<int>
        {
            9002009,  // 倾覆万千之流
        };

        // 可受多次流强化的卡牌ID及其最大强化次数
        private static readonly Dictionary<int, int> _multiFlowBonusCards = new Dictionary<int, int>
        {
            { 9002004, 4 },  // 风暴分流 - 额外3次流强化
            { 9002006, 4 },  // 洋流，听我的号令 - 额外3次流强化
            { 9002008, 2 },  // 百川逐风 - 额外1次流强化
        };

        // [迅攻] 关键词ID
        private const string _rapidAssaultKeywordId = "SteriaRapidAssault";

        internal static bool HasRapidAssaultKeyword(BattlePlayingCardDataInUnitModel card)
        {
            if (card?.card?.XmlData?.Keywords != null && card.card.XmlData.Keywords.Contains(_rapidAssaultKeywordId))
            {
                return true;
            }

            string[] abilityKeywords = card?.cardAbility?.Keywords;
            if (abilityKeywords != null)
            {
                for (int i = 0; i < abilityKeywords.Length; i++)
                {
                    if (abilityKeywords[i] == _rapidAssaultKeywordId)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        internal static bool IsRapidAssaultFaster(BattlePlayingCardDataInUnitModel card)
        {
            if (card == null || card.target == null)
            {
                return false;
            }

            if (!HasRapidAssaultKeyword(card))
            {
                return false;
            }

            int mySpeed = GetSpeedValue(card);
            int targetSpeed = GetTargetSpeedValue(card);
            if (mySpeed <= 0 || targetSpeed <= 0)
            {
                return false;
            }

            return mySpeed > targetSpeed;
        }

        internal static bool IsRapidAssaultFaster(BattlePlayingCardDataInUnitModel card, BattlePlayingCardDataInUnitModel opponent)
        {
            if (card == null || opponent == null)
            {
                return false;
            }

            if (!HasRapidAssaultKeyword(card))
            {
                return false;
            }

            int mySpeed = GetSpeedValue(card);
            int opponentSpeed = GetSpeedValue(opponent);
            if (mySpeed <= 0 || opponentSpeed <= 0)
            {
                return false;
            }

            return mySpeed > opponentSpeed;
        }

        private static int GetSpeedValue(BattlePlayingCardDataInUnitModel card)
        {
            if (card == null)
            {
                return -1;
            }

            if (card.speedDiceResultValue > 0)
            {
                return card.speedDiceResultValue;
            }

            BattleUnitModel unit = card.owner;
            if (unit?.speedDiceResult == null)
            {
                return -1;
            }

            int slot = card.slotOrder;
            if (slot < 0 || slot >= unit.speedDiceResult.Count)
            {
                return -1;
            }

            return unit.GetSpeedDiceResult(slot).value;
        }

        private static int GetTargetSpeedValue(BattlePlayingCardDataInUnitModel card)
        {
            if (card?.target == null)
            {
                return -1;
            }

            int targetSlotOrder = card.targetSlotOrder;
            if (targetSlotOrder < 0 || card.target.speedDiceResult == null || targetSlotOrder >= card.target.speedDiceResult.Count)
            {
                return -1;
            }

            BattlePlayingCardDataInUnitModel targetCard = null;
            if (card.target.cardSlotDetail?.cardAry != null && targetSlotOrder < card.target.cardSlotDetail.cardAry.Count)
            {
                targetCard = card.target.cardSlotDetail.cardAry[targetSlotOrder];
            }

            int targetSpeed = GetSpeedValue(targetCard);
            if (targetSpeed > 0)
            {
                return targetSpeed;
            }

            return card.target.GetSpeedDiceResult(targetSlotOrder).value;
        }

        // 存储每颗骰子的原始流强化次数（未乘以倍率，用于计算debuff层数）
        private static Dictionary<BattlePlayingCardDataInUnitModel, Dictionary<int, int>> _flowEnhancementCountPerCard =
            new Dictionary<BattlePlayingCardDataInUnitModel, Dictionary<int, int>>();

        /// <summary>
        /// 获取骰子的原始流强化次数（未乘以倍率）
        /// </summary>
        public static int GetFlowEnhancementCountForDice(BattlePlayingCardDataInUnitModel card, int diceIndex)
        {
            if (card != null && _flowEnhancementCountPerCard.TryGetValue(card, out var countMap))
            {
                if (countMap.TryGetValue(diceIndex, out int count))
                {
                    return count;
                }
            }
            return 0;
        }

        // 存储群攻卡牌消耗的流数量（用于额外伤害计算）
        private static Dictionary<BattlePlayingCardDataInUnitModel, int> _massAttackFlowConsumed =
            new Dictionary<BattlePlayingCardDataInUnitModel, int>();

        /// <summary>
        /// 获取群攻卡牌消耗的流数量
        /// </summary>
        public static int GetMassAttackFlowConsumed(BattlePlayingCardDataInUnitModel card)
        {
            if (card != null && _massAttackFlowConsumed.TryGetValue(card, out int consumed))
            {
                return consumed;
            }
            return 0;
        }

        /// <summary>
        /// 检查并消耗潮来增强荆棘效果
        /// 荆棘是被潮影响的负面效果，施加时消耗1层潮并增加1层荆棘
        /// </summary>
        /// <returns>潮加成的层数（0或1）</returns>
        public static int CheckAndConsumeTideForThorn(BattleUnitModel giver)
        {
            if (giver == null) return 0;
            if (IsTideEnhancementSuppressed) return 0;

            BattleUnitBuf_Tide tideBuf = giver.bufListDetail?.GetActivatedBufList()
                ?.FirstOrDefault(b => b is BattleUnitBuf_Tide) as BattleUnitBuf_Tide;

            if (tideBuf == null || tideBuf.stack <= 0) return 0;

            // 消耗1层潮，增加1层荆棘
            tideBuf.stack--;
            SteriaLogger.Log($"Tide: Giver {giver.UnitData?.unitData?.name} consumed 1 Tide for Thorn, remaining = {tideBuf.stack}");
            NotifyPassivesOnTideConsumed(giver, 1);

            if (tideBuf.stack <= 0)
            {
                tideBuf.Destroy();
            }

            return 1;
        }

        /// <summary>
        /// 清除群攻卡牌消耗记录
        /// </summary>
        public static void ClearMassAttackFlowConsumed(BattlePlayingCardDataInUnitModel card)
        {
            if (card != null)
            {
                _massAttackFlowConsumed.Remove(card);
            }
        }

        /// <summary>
        /// 检查卡牌是否具有"流转"效果
        /// </summary>
        public static bool IsFlowTransferCard(int cardId)
        {
            return _flowTransferCardIds.Contains(cardId);
        }

        internal static bool HasFlowTransferKeyword(BattlePlayingCardDataInUnitModel card)
        {
            if (card?.card?.XmlData?.Keywords != null && card.card.XmlData.Keywords.Contains(_flowTransferKeywordId))
            {
                return true;
            }

            string[] abilityKeywords = card?.cardAbility?.Keywords;
            if (abilityKeywords != null)
            {
                for (int i = 0; i < abilityKeywords.Length; i++)
                {
                    if (abilityKeywords[i] == _flowTransferKeywordId)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        internal static bool IsPhantomDreamCard(BattleDiceCardModel card)
        {
            return card?.XmlData?.Keywords != null && card.XmlData.Keywords.Contains(_phantomDreamKeywordId);
        }

        internal static int GetPhantomDreamCost(BattleDiceCardModel card)
        {
            return Math.Max(1, Math.Max(0, card?.GetCost() ?? 0) + 1);
        }

        internal static bool CanTargetAllyWithPhantomDream(BattleDiceCardModel card, BattleUnitModel actor, BattleUnitModel target, int targetDiceIdx)
        {
            if (!IsPhantomDreamCard(card) || actor == null || target == null || actor == target)
            {
                return false;
            }

            if (card.XmlData.IsEgo() || card.XmlData.IsPersonal() || card.XmlData.IsFloorEgo())
            {
                return false;
            }

            if (actor.faction != target.faction || SivierCardHelper.GetDreamCount(actor) < GetPhantomDreamCost(card))
            {
                return false;
            }

            if (target.bufListDetail == null || target.TeamKill() || !target.IsTargetable(actor))
            {
                return false;
            }

            if (actor.faction == Faction.Player && !target.bufListDetail.IsControlable())
            {
                return false;
            }

            if (targetDiceIdx >= 0)
            {
                if (target.speedDiceResult == null || targetDiceIdx >= target.speedDiceResult.Count)
                {
                    return false;
                }

                if (actor.faction == Faction.Player && !target.speedDiceResult[targetDiceIdx].isControlable)
                {
                    return false;
                }
            }

            List<BattleUnitModel> fixedTargets = actor.GetFixedTargets();
            if (fixedTargets != null && fixedTargets.Count > 0 && !fixedTargets.Contains(target))
            {
                return false;
            }

            return card.IsValidTarget(actor, card, target);
        }

        internal static bool TryResolvePhantomDreamTransfer(BattleUnitModel owner, BattleDiceCardModel sourceCard, BattleUnitModel target, int targetDiceIdx = -1)
        {
            if (!CanTargetAllyWithPhantomDream(sourceCard, owner, target, targetDiceIdx))
            {
                return false;
            }

            int dream = SivierCardHelper.GetDreamCount(owner);
            int dreamToConsume = GetPhantomDreamCost(sourceCard);
            if (dream < dreamToConsume)
            {
                SteriaLogger.Log($"PhantomDream: not enough Dream to consume, required {dreamToConsume}, current {dream}");
                return false;
            }

            if (owner.allyCardDetail == null || target.allyCardDetail == null)
            {
                return false;
            }

            BattleDiceCardModel copiedCard = BattleDiceCardModel.CreatePlayingCard(sourceCard.XmlData);
            if (copiedCard == null)
            {
                return false;
            }

            copiedCard.owner = target;
            copiedCard.SetCurrentCost(0);
            copiedCard.SetCostToZero(true);
            copiedCard.temporary = true;
            copiedCard.isCopiedCard = true;

            if (copiedCard.XmlData.optionList == null)
            {
                copiedCard.XmlData.optionList = new List<CardOption>();
            }
            if (!copiedCard.XmlData.optionList.Contains(CardOption.ExhaustOnUse))
            {
                copiedCard.XmlData.optionList.Add(CardOption.ExhaustOnUse);
            }
            if (copiedCard.XmlData.Keywords == null)
            {
                copiedCard.XmlData.Keywords = new List<string>();
            }
            if (!copiedCard.XmlData.Keywords.Contains(_phantomDreamKeywordId))
            {
                copiedCard.XmlData.Keywords.Add(_phantomDreamKeywordId);
            }
            copiedCard.AddBufWithoutDuplication(new global::BattleDiceCardBuf_PhantomDreamTransferred());

            owner.allyCardDetail.UseCard(sourceCard);
            owner.SpendCardAndCost(sourceCard);
            SivierCardHelper.ConsumeDream(owner, dreamToConsume);
            target.allyCardDetail.AddCardToHand(copiedCard, false);
            SivierCardHelper.PlayPhantomDreamSpecialMotion(owner);

            BattleUnitBuf_DreamIllusion dreamIllusion = owner.bufListDetail?.GetActivatedBufList()
                ?.FirstOrDefault(b => b is BattleUnitBuf_DreamIllusion) as BattleUnitBuf_DreamIllusion;
            dreamIllusion?.OnCardUsed();

            SingletonBehavior<BattleManagerUI>.Instance?.ui_unitCardsInHand?.UpdateCardList();
            SteriaLogger.Log($"PhantomDream: {owner.UnitData?.unitData?.name} consumed {dreamToConsume} Dream to transfer a 0-cost exhausted copy of {sourceCard.GetName()} to {target.UnitData?.unitData?.name}");
            return true;
        }

        /// <summary>
        /// 兼容旧调用名：当前含义为"流转"卡牌。
        /// </summary>
        public static bool IsFlowBonusOnlyCard(int cardId)
        {
            return IsFlowTransferCard(cardId);
        }

        /// <summary>
        /// 通知所有相关被动流被消耗
        /// </summary>
        public static void NotifyPassivesOnFlowConsumed(BattleUnitModel owner, int amount)
        {
            if (owner == null || amount <= 0) return;

            // 通知 PassiveAbility_9002001 (神脉：梦之汐-司流-倾覆之大流)
            var passive9002001 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9002001) as PassiveAbility_9002001;
            passive9002001?.OnFlowConsumed(amount);

            // 通知 PassiveAbility_9000005 (不会忘记的那个梦想)
            var passive9000005 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9000005) as PassiveAbility_9000005;
            passive9000005?.OnFlowConsumed(amount);

            // 通知 PassiveAbility_9002003 (御风司流)
            var passive9002003 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9002003) as PassiveAbility_9002003;
            passive9002003?.OnFlowConsumed(amount);

            // 通知 PassiveAbility_9002004 (司流者)
            var passive9002004 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9002004) as PassiveAbility_9002004;
            passive9002004?.OnFlowConsumed(amount);

            // 通知 PassiveAbility_9002005 (斯拉泽雅司流者)
            var passive9002005 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9002005) as PassiveAbility_9002005;
            passive9002005?.OnFlowConsumed(amount);

            // 通知 PassiveAbility_9007001 (汐音共振)
            var passive9007001 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9007001) as PassiveAbility_9007001;
            passive9007001?.OnFlowConsumed(amount);

            SteriaLogger.Log($"NotifyPassivesOnFlowConsumed: Notified passives of {amount} flow consumed");
        }

        /// <summary>
        /// 通知所有相关被动潮被消耗
        /// </summary>
        public static void NotifyPassivesOnTideConsumed(BattleUnitModel owner, int amount, bool isGolden = false, BattleUnitModel enhancedTarget = null, KeywordBuf enhancedBufType = KeywordBuf.None, bool enhancedByTide = false)
        {
            if (owner == null || amount <= 0) return;

            var passive9006001 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9006001) as PassiveAbility_9006001;
            passive9006001?.OnTideConsumed(amount);

            // PassiveAbility_9009002 (金色的乐章) 旧版的"乐谱进度"已随乐章型骰子重制移除，不再监听潮消耗。

            var passive9009004 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9009004) as PassiveAbility_9009004;
            passive9009004?.OnTideConsumed(amount);

            var passive9011001 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9011001) as PassiveAbility_9011001;
            passive9011001?.OnTideConsumed(amount, enhancedTarget, enhancedBufType, enhancedByTide);

            if (isGolden)
            {
                var passive9009008 = owner.passiveDetail.PassiveList?.FirstOrDefault(p => p is PassiveAbility_9009008) as PassiveAbility_9009008;
                passive9009008?.OnGoldenTideConsumed(amount);
            }

            ChristashaAbilityHelper.AddTwinStarTideConsumed(owner, amount);

            SteriaLogger.Log($"NotifyPassivesOnTideConsumed: Notified passives of {amount} tide consumed");
            TideConsumptionTracker.NotifyConsumed(owner, isGolden);
        }

        /// <summary>
        /// 注册新的"流转"卡牌ID（运行时动态添加）
        /// </summary>
        public static void RegisterFlowTransferCard(int cardId)
        {
            _flowTransferCardIds.Add(cardId);
            SteriaLogger.Log($"Registered card ID {cardId} as FlowTransfer card");
        }

        /// <summary>
        /// 兼容旧调用名：当前含义为注册"流转"卡牌。
        /// </summary>
        public static void RegisterFlowBonusOnlyCard(int cardId)
        {
            RegisterFlowTransferCard(cardId);
        }

        private static void ScheduleFlowTransferRefund(BattleUnitModel owner, int amount, int cardId)
        {
            if (owner == null || owner.bufListDetail == null || amount <= 0)
            {
                return;
            }

            BattleUnitBuf_FlowTransferRefundNextRound existing = owner.bufListDetail.GetActivatedBufList()
                ?.FirstOrDefault(b => b is BattleUnitBuf_FlowTransferRefundNextRound && !b.IsDestroyed()) as BattleUnitBuf_FlowTransferRefundNextRound;

            if (existing != null)
            {
                existing.stack += amount;
            }
            else
            {
                owner.bufListDetail.AddBuf(new BattleUnitBuf_FlowTransferRefundNextRound { stack = amount });
            }

            SteriaLogger.Log($"FlowTransfer: Card {cardId} will refund {amount} Flow next round");
        }

        // All ordinary enhancement is assigned to hand instances during planning.
        // Execution only binds the locked record; it never redistributes or spends Flow.
        public static void RegisterCardUsage(BattlePlayingCardDataInUnitModel card)
        {
            BindManualFlow(card);
        }

        // 获取骰子的流威力加成（通过卡牌和骰子索引）
        public static int GetFlowPowerBonusForDice(BattlePlayingCardDataInUnitModel card, int diceIndex)
        {
            if (card != null && _flowPowerBonusPerCard.TryGetValue(card, out var bonusMap))
            {
                if (bonusMap.TryGetValue(diceIndex, out int bonus))
                {
                    return bonus;
                }
            }
            return 0;
        }

        // 清除骰子的流威力加成记录
        public static void ClearFlowPowerBonusForDice(BattlePlayingCardDataInUnitModel card, int diceIndex)
        {
            if (card != null && _flowPowerBonusPerCard.TryGetValue(card, out var bonusMap))
            {
                bonusMap.Remove(diceIndex);
                if (bonusMap.Count == 0)
                {
                    _flowPowerBonusPerCard.Remove(card);
                }
            }
        }

        // 清除卡牌的所有流威力加成记录
        public static void ClearAllFlowPowerBonusForCard(BattlePlayingCardDataInUnitModel card)
        {
            if (card != null)
            {
                _flowPowerBonusPerCard.Remove(card);
            }
        }

        // 检查卡牌是否有流威力加成记录
        public static bool HasFlowBonusForCard(BattlePlayingCardDataInUnitModel card)
        {
            return card != null && _flowPowerBonusPerCard.ContainsKey(card);
        }

        // 调试用：输出当前所有流威力加成记录
        public static void DebugLogAllFlowBonuses()
        {
            SteriaLogger.Log($"=== Flow Bonus Dictionary Debug ===");
            SteriaLogger.Log($"Total cards in dictionary: {_flowPowerBonusPerCard.Count}");
            foreach (var kvp in _flowPowerBonusPerCard)
            {
                SteriaLogger.Log($"  Card Hash={kvp.Key.GetHashCode()}, CardID={kvp.Key.card?.GetID()}");
                foreach (var diceKvp in kvp.Value)
                {
                    SteriaLogger.Log($"    Dice {diceKvp.Key}: +{diceKvp.Value} power");
                }
            }
            SteriaLogger.Log($"=== End Debug ===");
        }

        // Method called after a card has finished its action
        public static void CleanupCardUsage(BattlePlayingCardDataInUnitModel card)
        {
            if (card == null) return;
            bool removedRule = _flowConsumingCards.Remove(card);
            bool removedConsumption = _flowConsumedByCardAction.Remove(card); // Also clear the total consumed for this card
            Debug.Log($"[MyDLL] Cleaned up Card Usage: ID={card.card?.GetID()}, Hash={card.GetHashCode()}. Removed Rule: {removedRule}, Removed Consumption: {removedConsumption}");

            // 清除流加成记录（包括反击骰子的加成）
            ClearAllFlowPowerBonusForCard(card);
            // 清除流强化次数记录
            _flowEnhancementCountPerCard.Remove(card);
            // 清除已应用流加成的骰子记录
            ClearFlowBonusAppliedDice();
            SteriaLogger.Log($"CleanupCardUsage: Cleared flow bonus records for card {card.card?.GetID()}");

            // Clear dice consumption for behaviors associated with this card - IMPORTANT
             List<BattleDiceBehavior> behaviors = card.GetDiceBehaviorList();
             if (behaviors != null) {
                foreach(var behavior in behaviors) {
                 if (behavior != null) {
                     _flowConsumedByDiceAction.Remove(behavior);
                     // Also remove from repeat set if the action ends prematurely
                     _repeatTriggeredDice.Remove(behavior);
                     RemoveTideRevelationApplied(behavior);
                 }
             }
             }
        }
    }


    // Contains all Harmony Patches for the mod
    // BaseMod will automatically discover and apply patches from classes
    // marked with [HarmonyPatch] if the assembly is loaded correctly.
    // However, base PatchAll only applies patches defined in this file or similar structure in the DLL.
    // Individual mods need their own PatchAll call in their Initializer.
    [HarmonyPatch] 
    public static class HarmonyPatches 
    {
        private static int _globalFlowPowerBonusThisRound = 0;

        public static void AddGlobalFlowPowerBonusThisRound(int amount, BattleUnitModel source = null)
        {
            if (amount <= 0) return;
            _globalFlowPowerBonusThisRound += amount;
            SteriaLogger.Log($"GlobalFlowPowerBonus +{amount} (total={_globalFlowPowerBonusThisRound}), source={source?.UnitData?.unitData?.name}");
        }

        // 原初之潮：仅允许流/梦体系来源改动威力
        [HarmonyPatch(typeof(BattleDiceBehavior), nameof(BattleDiceBehavior.ApplyDiceStatBonus))]
        public static class BattleDiceBehavior_ApplyDiceStatBonus_PrimalTidePatch
        {
            [HarmonyPrefix]
            public static bool Prefix(BattleDiceBehavior __instance, DiceStatBonus bonus)
            {
                try
                {
                    if (__instance?.owner == null || bonus == null)
                    {
                        return true;
                    }

                    if (!global::ChristashaEgoBossHelper.HasPrimalTide(__instance.owner))
                    {
                        return true;
                    }

                    if (global::PrimalTidePowerScope.IsAllowanceActive)
                    {
                        return true;
                    }

                    if (bonus.power == 0)
                    {
                        return true;
                    }

                    bonus.power = 0;
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] PrimalTide ApplyDiceStatBonus patch error: {ex}");
                    return true;
                }
            }
        }

        // Removed _harmonyInstance and _patched fields
        // Removed Initialize() and Unpatch() methods - ModInitializer handles PatchAll now

        // --- REMOVED TEST PATCH --- 
        // [HarmonyPatch(typeof(PassiveAbilityBase), nameof(PassiveAbilityBase.OnRoundStart))]
        // public static class PassiveAbilityBase_OnRoundStart_TestPatch { ... } // Removed
        // --- END OF REMOVED TEST PATCH ---

        // --- Helper to notify Passive 9000003 about discard events ---
        private static void NotifyPassive9000003(BattleUnitModel owner)
        {
            if (owner?.passiveDetail?.PassiveList == null) return;
            var passive = owner.passiveDetail.PassiveList.FirstOrDefault(p => p is PassiveAbility_9000003) as PassiveAbility_9000003;
            passive?.Notify_CardDiscarded();
        }

        // --- Helper to increment discard count for 以执为攻 (按角色计数) ---
        private static void IncrementDiscardCountForUnit(BattleUnitModel unit)
        {
            DiceCardSelfAbility_AnhierDiscardPowerUp.IncrementDiscardCount(unit);
        }

        // --- Helper to handle 珍贵的回忆 被弃置时的效果 ---
        private const int PRECIOUS_MEMORY_NUMERIC_ID = 9001006;
        private const string MOD_PACKAGE_ID = "SteriaBuilding";

        private static void HandlePreciousMemoryDiscard(BattleUnitModel owner, BattleDiceCardModel card)
        {
            if (owner == null || card == null || card.GetID() == null)
            {
                SteriaLogger.LogWarning("HandlePreciousMemoryDiscard: null owner/card/ID");
                return;
            }

            LorId cardId = card.GetID();
            SteriaLogger.Log($"HandlePreciousMemoryDiscard: Card='{card.GetName()}', ID={cardId.id}, PkgId='{cardId.packageId}'");

            // 检查是否是珍贵的回忆 (同时检查 packageId 和 id)
            bool isPreciousMemory =
                cardId.id == PRECIOUS_MEMORY_NUMERIC_ID &&
                (string.IsNullOrEmpty(cardId.packageId) || cardId.packageId == MOD_PACKAGE_ID);

            if (!isPreciousMemory)
                return;

            SteriaLogger.Log("珍贵的回忆 被弃置! 触发效果: 抽2张牌 + 下一幕获得1层[强壮]");

            // 抽2张牌
            owner.allyCardDetail.DrawCards(2);
            SteriaLogger.Log("抽取了2张牌");

            // AddKeywordBufByEtc 默认下一幕生效，直接赋予即可
            try
            {
                owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Strength, 1, owner);
                SteriaLogger.Log("赋予了1层强壮（下一幕生效）");
            }
            catch (Exception ex)
            {
                SteriaLogger.LogError($"赋予强壮失败: {ex.Message}");
            }

            // 消耗这张牌（只消耗当前这一张，不影响其他同ID卡牌）
            try
            {
                owner.allyCardDetail.ExhaustACardAnywhere(card);
                SteriaLogger.Log("消耗了珍贵的回忆");
            }
            catch (Exception ex)
            {
                SteriaLogger.LogError($"消耗珍贵的回忆失败: {ex.Message}");
            }

            // 通知 PassiveAbility_9000005 (不会忘记的那个梦想) 珍贵的回忆被弃置
            var passive9000005 = owner.passiveDetail.PassiveList?
                .FirstOrDefault(p => p is PassiveAbility_9000005) as PassiveAbility_9000005;
            if (passive9000005 != null)
            {
                passive9000005.OnPreciousMemoryDiscarded();
                SteriaLogger.Log("通知了 PassiveAbility_9000005 珍贵的回忆被弃置");
            }
        }

        private const int CHRISTASHA_TWINSTAR_ID = 9009007;

        private static bool IsChristashaTwinStar(BattlePlayingCardDataInUnitModel card)
        {
            if (card?.card == null) return false;
            LorId id = card.card.GetID();
            if (id == null || id.id != CHRISTASHA_TWINSTAR_ID) return false;
            return string.IsNullOrEmpty(id.packageId) || id.packageId == MOD_PACKAGE_ID;
        }


        // --- Patches for Passive 9000001 (神脉：职业等级) --- 
        [HarmonyPatch(typeof(BattleUnitModel), nameof(BattleUnitModel.TakeDamage))]
        public static class PassiveAbility_9000001_Patch_TakeDamage
        {
            public static void Prefix(BattleUnitModel __instance, ref int v, DamageType type, BattleUnitModel attacker)
            {
                if (attacker?.passiveDetail?.PassiveList.Any(p => p is PassiveAbility_9000001) == true && v > 0 && type == DamageType.Attack)
                {
                    int originalDmg = v;
                    v = (int)Math.Round(v * 1.15f);
                    Debug.Log($"[MyDLL] Passive 9000001 (Attacker: {attacker.UnitData.unitData.name}): Increasing damage to {__instance.UnitData.unitData.name} from {originalDmg} to {v} (+15%)");
                }
            }
        }

        [HarmonyPatch(typeof(BattleUnitModel), nameof(BattleUnitModel.TakeBreakDamage))]
        public static class PassiveAbility_9000001_Patch_TakeBreakDamage
        {
            public static void Prefix(BattleUnitModel __instance, ref int damage, DamageType type, BattleUnitModel attacker, AtkResist atkResist)
            {
                if (attacker?.passiveDetail?.PassiveList.Any(p => p is PassiveAbility_9000001) == true && damage > 0)
                {
                    int originalBreakDmg = damage;
                    damage = (int)Math.Round(damage * 1.15f);
                    Debug.Log($"[MyDLL] Passive 9000001 (Attacker: {attacker.UnitData.unitData.name}): Increasing break damage to {__instance.UnitData.unitData.name} from {originalBreakDmg} to {damage} (+15%)");
                }
            }
        }

        [HarmonyPatch(typeof(SpeedDiceRule), nameof(SpeedDiceRule.Roll))]
        public static class PassiveAbility_9000001_Patch_SpeedDiceRoll
        {
            public static void Postfix(SpeedDiceRule __instance, ref List<SpeedDice> __result, BattleUnitModel unitModel)
            {
                if (unitModel?.passiveDetail?.PassiveList.Any(p => p is PassiveAbility_9000001) == true && __result != null)
                {
                    foreach (SpeedDice dice in __result)
                    {
                        dice.faces += 1;
                    }
                }
            }
        }


        // --- Patches for Passive 9000002 (神脉：汐与梦) + 倾诉梦想：远望 + 薇莉亚被动 ---
        [HarmonyPatch(typeof(BattlePlayingCardSlotDetail), nameof(BattlePlayingCardSlotDetail.SpendCost))]
        public static class BattlePlayingCardSlotDetail_SpendCost_Patch
        {
            public static void Postfix(BattlePlayingCardSlotDetail __instance, int value)
            {
                // 字段名是 _self 而不是 _owner
                var selfField = AccessTools.Field(typeof(BattlePlayingCardSlotDetail), "_self");
                BattleUnitModel owner = selfField?.GetValue(__instance) as BattleUnitModel;
                if (owner != null && value > 0)
                {
                    // 触发 PassiveAbility_9000002 (神脉：汐与梦)
                    var passive = owner.passiveDetail.PassiveList.FirstOrDefault(p => p is PassiveAbility_9000002) as PassiveAbility_9000002;
                    passive?.OnActualLightSpend(value);

                    // 触发 PassiveAbility_9004001 (神脉：梦之汐-司潮-潜力观测) - 薇莉亚耗光给潮
                    var passive9004001 = owner.passiveDetail.PassiveList.FirstOrDefault(p => p is PassiveAbility_9004001) as PassiveAbility_9004001;
                    passive9004001?.OnLightSpent(value);

                    // 触发 倾诉梦想：远望 Buff
                    var dreamVisionBuf = owner.bufListDetail.GetActivatedBufList()
                        .FirstOrDefault(b => b is BattleUnitBuf_DreamVision) as BattleUnitBuf_DreamVision;
                    dreamVisionBuf?.OnLightSpent(value);
                }
            }
        }

        // --- Patches for Passive 9000003 (回忆燃烧) 以及 珍贵的回忆 弃置触发 ---

        [HarmonyPatch(typeof(BattleUnitModel), nameof(BattleUnitModel.OnDiscardByAbility))]
        public static class BattleUnitModel_OnDiscardByAbility_Patch
        {
            [HarmonyPostfix]
            public static void Postfix(BattleUnitModel __instance, List<BattleDiceCardModel> cards)
            {
                try
                {
                    if (__instance == null || cards == null || cards.Count == 0)
                        return;

                    foreach (BattleDiceCardModel card in cards)
                    {
                        HandlePreciousMemoryDiscard(__instance, card);
                    }

                    // 通知 回忆燃烧 被动本幕有弃牌发生
                    NotifyPassive9000003(__instance);
                    // 增加弃牌计数（以执为攻，按角色计数）
                    IncrementDiscardCountForUnit(__instance);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[MyDLL] Error in BattleUnitModel_OnDiscardByAbility_Patch Postfix: {ex}");
                }
            }
        }

        // --- Patch for BattleAllyCardDetail.DiscardACardByAbility (单张弃牌) ---
        // 指定参数类型以避免重载歧义
        [HarmonyPatch(typeof(BattleAllyCardDetail), nameof(BattleAllyCardDetail.DiscardACardByAbility), new Type[] { typeof(BattleDiceCardModel) })]
        public static class BattleAllyCardDetail_DiscardACardByAbility_Patch
        {
            [HarmonyPostfix]
            public static void Postfix(BattleAllyCardDetail __instance, BattleDiceCardModel card)
            {
                try
                {
                    if (__instance == null || card == null)
                        return;

                    // 获取 owner
                    var ownerField = AccessTools.Field(typeof(BattleAllyCardDetail), "_owner");
                    BattleUnitModel owner = ownerField?.GetValue(__instance) as BattleUnitModel;

                    if (owner == null)
                    {
                        SteriaLogger.LogWarning("DiscardACardByAbility_Patch: Could not get owner");
                        return;
                    }

                    SteriaLogger.Log($"DiscardACardByAbility_Patch: Card='{card.GetName()}', Owner={owner.UnitData?.unitData?.name}");
                    HandlePreciousMemoryDiscard(owner, card);
                    NotifyPassive9000003(owner);
                    IncrementDiscardCountForUnit(owner);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in BattleAllyCardDetail_DiscardACardByAbility_Patch Postfix: {ex}");
                }
            }
        }

        // --- Patch for BattleAllyCardDetail.DisCardACardRandom (随机弃牌) ---
        [HarmonyPatch(typeof(BattleAllyCardDetail), nameof(BattleAllyCardDetail.DisCardACardRandom))]
        public static class BattleAllyCardDetail_DisCardACardRandom_Patch
        {
            [HarmonyPostfix]
            public static void Postfix(BattleAllyCardDetail __instance, BattleDiceCardModel __result)
            {
                try
                {
                    if (__instance == null || __result == null)
                        return;

                    // 获取 owner
                    var ownerField = AccessTools.Field(typeof(BattleAllyCardDetail), "_owner");
                    BattleUnitModel owner = ownerField?.GetValue(__instance) as BattleUnitModel;

                    if (owner == null)
                    {
                        SteriaLogger.LogWarning("DisCardACardRandom_Patch: Could not get owner");
                        return;
                    }

                    SteriaLogger.Log($"DisCardACardRandom_Patch: Card='{__result.GetName()}', Owner={owner.UnitData?.unitData?.name}");
                    HandlePreciousMemoryDiscard(owner, __result);
                    NotifyPassive9000003(owner);
                    IncrementDiscardCountForUnit(owner);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in BattleAllyCardDetail_DisCardACardRandom_Patch Postfix: {ex}");
                }
            }
        }

        // --- REMOVED PATCH for Passive 9000004 (回忆结晶) ---
        // [HarmonyPatch(typeof(StageController), nameof(StageController.SetCurrentWave))]
        // public static class StageController_SetCurrentWave_Patch { ... } // Removed
        // --- END OF REMOVED PATCH for Passive 9000004 ---

        // --- REMOVED BattleUnitModel_OnWaveStart_Patch Class ---

        // --- REMOVED Patch for Battle Start (No longer needed as logic is in passive Init/OnWaveStart) ---
        // [HarmonyPatch(typeof(StageController), nameof(StageController.StartBattle))]
        // public static class StageController_StartBattle_Patch { ... }

        // --- REMOVED Patch for Scene Start (Logic moved to Passive OnWaveStart) ---
        // [HarmonyPatch(typeof(StageController), nameof(StageController.NextWave))]
        // public static class StageController_NextWave_Patch { ... } 
        
        // --- Patch for Battle Start to Reset Discard Counts ---
        [HarmonyPatch(typeof(StageController), nameof(StageController.StartBattle))]
        public static class StageController_StartBattle_Patch
        {
            [HarmonyPostfix]
            public static void Postfix()
            {
                // PassiveAbility_9000004 现在使用实例变量，Init时自动重置，不需要手动重置
                DiceCardSelfAbility_AnhierDiscardPowerUp.ResetAllDiscardCounts(); // Reset all discard counts for 以执为攻
                Debug.Log("[Steria] StartBattle: Reset discard counts");
            }
        }

        // --- Patch for Battle End to Reset Counters ---
        [HarmonyPatch(typeof(StageController), nameof(StageController.EndBattle))]
        public static class StageController_EndBattle_ResetCounters_Patch
        {
            [HarmonyPostfix]
            public static void Postfix()
            {
                // PassiveAbility_9000004 现在使用实例变量，不需要手动重置
                DiceCardSelfAbility_AnhierDiscardPowerUp.ResetAllDiscardCounts(); // Reset discard counts
                DiceCardSelfAbility_ChristashaGlory.ClearStoredGrowth();
                ChristashaAbilityHelper.ClearTwinStarTideConsumed();
                Debug.Log("[Steria] EndBattle: Reset discard counts");
            }
        }

        // --- Patch for CloseBattleScene to Reset Counters (backup) ---
        [HarmonyPatch(typeof(StageController), nameof(StageController.CloseBattleScene))]
        public static class StageController_CloseBattleScene_ResetCounters_Patch
        {
            [HarmonyPostfix]
            public static void Postfix()
            {
                // PassiveAbility_9000004 现在使用实例变量，不需要手动重置
                DiceCardSelfAbility_AnhierDiscardPowerUp.ResetAllDiscardCounts(); // Reset discard counts
                DiceCardSelfAbility_ChristashaGlory.ClearStoredGrowth();
                ChristashaAbilityHelper.ClearTwinStarTideConsumed();
                Debug.Log("[Steria] CloseBattleScene: Reset discard counts");
            }
        }

        // --- Patch for SetCurrentWave to Reset Discard Counter for 以执为攻 ---
        [HarmonyPatch(typeof(StageController), nameof(StageController.SetCurrentWave))]
        public static class StageController_SetCurrentWave_ResetDiscardCount_Patch
        {
            [HarmonyPostfix]
            public static void Postfix()
            {
                DiceCardSelfAbility_AnhierDiscardPowerUp.ResetAllDiscardCounts(); // Reset all discard counts at wave start
                Debug.Log("[Steria] SetCurrentWave: Reset discard counts for 以执为攻");
            }
        }

        // --- RoundStartPhase_System Patch 已移除 ---
        // 回忆结晶 (PassiveAbility_9000004) 的逻辑现在在 OnRoundStart 中处理

        // --- Patch to Clear Flow Consumption Tracking at Round Start ---
        [HarmonyPatch(typeof(StageController), "RoundStartPhase_System")]
        [HarmonyPrefix] // Run before the original method
        public static void StageController_RoundStartPhase_System_ClearTracking_Prefix()
        {
            try
            {
                // Call helper from the dedicated helper class
                HarmonyHelpers.ClearFlowConsumptionTracking(); 
            }
            catch (Exception ex)
            {
                Debug.LogError($"[MyDLL] Error in StageController_RoundStartPhase_System_ClearTracking_Prefix: {ex}");
            }
        }

        // --- NEW PATCHES FOR FLOW MECHANICS ---

        // Patch for Flow consumption and dice power bonus application
        [HarmonyPatch(typeof(BattlePlayingCardDataInUnitModel), "OnUseCard")]
        [HarmonyPrefix]
        public static void BattlePlayingCardDataInUnitModel_OnUseCard_Prefix(BattlePlayingCardDataInUnitModel __instance)
        {
            Debug.Log($"[Steria] Card Usage Start: ID={__instance.card?.GetID()}, Hash={__instance.GetHashCode()}, Owner={__instance.owner?.UnitData.unitData.name}");
            HarmonyHelpers.RegisterCardUsage(__instance);
        }

        // 注意：不要在 OnUseCard Postfix 中清除流加成记录
        // 因为 Standby 骰子是在 OnUseCard 之后才被创建和使用的
        // 流加成记录应该在 OnEndBattle 中清除

        // Patch for OnEndBattle to cleanup flow bonus records
        // 在卡牌行动完全结束后清除流加成记录（包括 Standby 骰子使用后）
        [HarmonyPatch(typeof(BattlePlayingCardDataInUnitModel), "OnEndBattle")]
        [HarmonyPostfix]
        public static void BattlePlayingCardDataInUnitModel_OnEndBattle_Postfix(BattlePlayingCardDataInUnitModel __instance)
        {
            Debug.Log($"[Steria] Card OnEndBattle Postfix: ID={__instance.card?.GetID()}, Hash={__instance.GetHashCode()}");
            HarmonyHelpers.CleanupCardUsage(__instance);

            if (__instance?.card != null)
            {
                TibuAbilityHelper.ClearTideRevelation(__instance.card);
            }

            if (__instance?.owner != null)
            {
                var borrowedBuf = __instance.owner.bufListDetail.GetActivatedBufList()
                    .FirstOrDefault(b => b is global::BattleUnitBuf_TideBorrowedCard) as global::BattleUnitBuf_TideBorrowedCard;
                borrowedBuf?.ReturnBorrowedCard(__instance.card);
            }
        }

        // 新的简化流消耗逻辑：在 RollDice 时应用预先计算好的威力加成
        // 修改：使用 HashSet 跟踪已应用加成的骰子，而不是立即清除记录
        // 这样反击骰子（复制的骰子）也能获得相同的加成
        [HarmonyPatch(typeof(BattleDiceBehavior), nameof(BattleDiceBehavior.RollDice))]
        [HarmonyPrefix]
        public static void BattleDiceBehavior_RollDice_FlowPatch(BattleDiceBehavior __instance)
        {
            // 添加调试日志 - 每次 RollDice 都输出
            SteriaLogger.Log($"RollDice Patch TRIGGERED: Card={__instance.card?.card?.GetID()}, DiceIndex={__instance.Index}, CardHash={__instance.card?.GetHashCode()}, DiceHash={__instance.GetHashCode()}");

            if (__instance.card?.card == null || __instance.owner == null)
            {
                SteriaLogger.Log("RollDice Patch: card or owner is null, skipping");
                return;
            }

            // 检查这个骰子实例是否已经应用了流加成（防止重复应用）
            if (HarmonyHelpers.HasFlowBonusApplied(__instance))
            {
                SteriaLogger.Log($"RollDice Patch: Dice already has flow bonus applied, skipping");
                return;
            }

            // 检查字典中是否有这个卡牌的记录
            bool hasCardInDict = HarmonyHelpers.HasFlowBonusForCard(__instance.card);
            SteriaLogger.Log($"RollDice Patch: HasFlowBonusForCard={hasCardInDict}");

            // 使用卡牌实例和骰子索引来查找威力加成
            int diceIndex = __instance.Index;
            int flowBonus = HarmonyHelpers.GetFlowPowerBonusForDice(__instance.card, diceIndex);

            if (flowBonus > 0 && _globalFlowPowerBonusThisRound > 0)
            {
                flowBonus += _globalFlowPowerBonusThisRound;
                SteriaLogger.Log($"RollDice FlowPatch: Applying global flow bonus +{_globalFlowPowerBonusThisRound}, final bonus={flowBonus}");
            }

            SteriaLogger.Log($"RollDice Patch: DiceIndex={diceIndex}, FlowBonus={flowBonus}");

            if (flowBonus > 0)
            {
                SteriaLogger.Log($"RollDice FlowPatch: Applying +{flowBonus} power from flow to dice index {diceIndex}");
                global::PrimalTidePowerScope.RunWithAllowance(() =>
                    __instance.ApplyDiceStatBonus(new DiceStatBonus { power = flowBonus }));
                // 标记这个骰子实例已经应用了加成（防止重复应用）
                // 不清除记录，让反击骰子（复制的骰子）也能获得相同的加成
                HarmonyHelpers.MarkFlowBonusApplied(__instance);
            }
        }

        [HarmonyPatch(typeof(BattleDiceBehavior), nameof(BattleDiceBehavior.RollDice))]
        public static class BattleDiceBehavior_RollDice_TideRevelationPatch
        {
            [HarmonyPrefix]
            public static void Prefix(BattleDiceBehavior __instance)
            {
                try
                {
                    if (__instance == null || __instance.card?.card == null)
                    {
                        return;
                    }

                    if (HarmonyHelpers.HasTideRevelationApplied(__instance))
                    {
                        return;
                    }

                    if (TibuAbilityHelper.HasTideRevelation(__instance.card.card))
                    {
                        global::PrimalTidePowerScope.RunWithAllowance(() =>
                            __instance.ApplyDiceStatBonus(new DiceStatBonus { power = 1 }));
                        HarmonyHelpers.MarkTideRevelationApplied(__instance);
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] TideRevelation RollDice patch error: {ex}");
                }
            }
        }


        // Patch for SlazeyaClashLosePowerUpNextDice
        [HarmonyPatch(typeof(BattleUnitModel), nameof(BattleUnitModel.OnLoseParrying))]
        public static class BattleUnitModel_OnLoseParrying_Patch
        {
             [HarmonyPostfix]
             public static void Postfix(BattleUnitModel __instance, BattleDiceBehavior behavior)
             {
                 try
                 {
                     if (behavior == null) return;

                     // 检查是否有 SlazeyaClashLosePowerUpNextDice 能力
                     bool hasAbility = behavior.abilityList != null &&
                                       behavior.abilityList.Exists(a => a is DiceCardAbility_SlazeyaClashLosePowerUpNextDice);

                     if (!hasAbility) return;

                     Debug.Log($"[Steria] SlazeyaClashLosePowerUpNextDice: Triggered on dice {behavior.Index}");

                     BattlePlayingCardDataInUnitModel currentCard = behavior.card;
                     if (currentCard == null) return;

                     List<BattleDiceBehavior> behaviorList = currentCard.GetDiceBehaviorList();
                     if (behaviorList == null || behaviorList.Count == 0) return;

                     int currentDiceIdx = -1;
                     for (int i = 0; i < behaviorList.Count; i++)
                     {
                         if (behaviorList[i] == behavior)
                         {
                             currentDiceIdx = i;
                             break;
                         }
                     }

                     if (currentDiceIdx != -1 && currentDiceIdx + 1 < behaviorList.Count)
                     {
                         BattleDiceBehavior nextBehaviour = behaviorList[currentDiceIdx + 1];
                         // 使用骰子的最大值作为基础威力
                         int basePower = behavior.GetDiceMax();
                         if (basePower > 0)
                         {
                             DiceStatBonus bonus = new DiceStatBonus { power = basePower };
                             global::PrimalTidePowerScope.RunWithAllowance(() =>
                                 nextBehaviour.ApplyDiceStatBonus(bonus));
                             Debug.Log($"[Steria] SlazeyaClashLosePowerUpNextDice: Powered up dice {currentDiceIdx + 1} by {basePower}");
                         }
                     }
                 }
                 catch (Exception ex)
                 {
                     Debug.LogError($"[Steria] Error in OnLoseParrying_Patch: {ex}");
                 }
             }
        }

        // --- Patch for SlazeyaRepeatOnFlow5 Dice Repeat --- 
        [HarmonyPatch(typeof(BattleDiceBehavior), nameof(BattleDiceBehavior.GiveDamage))] // Patch after damage is dealt
        public static class BattleDiceBehavior_GiveDamage_RepeatPatch
        {
             [HarmonyPostfix]
             public static void Postfix(BattleDiceBehavior __instance) // __instance is the BattleDiceBehavior that just finished GiveDamage
             {
                 try
                 {
                     // Check if this behavior instance was marked for repeat by the ability
                     if (HarmonyHelpers._repeatTriggeredDice.Contains(__instance))
                     {
                         HarmonyHelpers._repeatTriggeredDice.Remove(__instance); // Remove immediately to prevent potential infinite loops

                         // --- Trigger the Repeat by setting isBonusAttack flag ---
                         // This marks the dice for a bonus attack.
                         // The _triggered flag within the ability instance *should* prevent the bonus attack
                         // from re-triggering the repeat marking if OnSucceedAttack runs again for it.
                         // The removal from _repeatTriggeredDice is the main safeguard.
                         Debug.Log($"[MyDLL] BattleDiceBehavior_GiveDamage_RepeatPatch: Repeating dice behavior (Hash: {__instance.GetHashCode()}, Index: {__instance.Index}) via isBonusAttack.");
                         __instance.isBonusAttack = true;
                     }
                 }
                 catch (Exception ex)
                 {
                      Debug.LogError($"[MyDLL] Error in BattleDiceBehavior_GiveDamage_RepeatPatch Postfix: {ex}");
                 }
             }
        }

        // --- Patch for Custom DiceAttackEffect (like 寒昼事务所) ---
        // 自定义特效字典
        public static Dictionary<string, Type> SteriaCustomEffects = new Dictionary<string, Type>();

        // 初始化自定义特效
        public static void InitCustomEffects()
        {
            SteriaCustomEffects.Clear();

            // Card-scoped, original RGBA phase animation; old effect callers retain their renderer.
            SteriaCustomEffects["Steria_AnhierTextureSeaPierce"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaPierce);
            SteriaCustomEffects["Steria_AnhierTextureSeaFarHit"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaFarHit);
            SteriaCustomEffects["Steria_AnhierTextureMemorySlash"] = typeof(DiceAttackEffect_Steria_AnhierTextureMemorySlash);
            SteriaCustomEffects["Steria_AnhierTextureMemoryPierce"] = typeof(DiceAttackEffect_Steria_AnhierTextureMemoryPierce);
            SteriaCustomEffects["Steria_AnhierTextureMemoryHit"] = typeof(DiceAttackEffect_Steria_AnhierTextureMemoryHit);
            SteriaCustomEffects["Steria_AnhierTextureMemoryGuard"] = typeof(DiceAttackEffect_Steria_AnhierTextureMemoryGuard);
            SteriaCustomEffects["Steria_AnhierTextureSeaSlash"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaSlash);
            SteriaCustomEffects["Steria_AnhierTextureSeaHit"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaHit);
            SteriaCustomEffects["Steria_AnhierTextureSeaGuard"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaGuard);

            // Public theme/action aliases reuse the same types, cache and authored assets.
            SteriaCustomEffects["Steria_OceanCurrentSlash"] = typeof(DiceAttackEffect_Steria_OceanCurrentSlash);
            SteriaCustomEffects["Steria_OceanCurrentHit"] = typeof(DiceAttackEffect_Steria_OceanCurrentHit);
            SteriaCustomEffects["Steria_OceanCurrentPierce"] = typeof(DiceAttackEffect_Steria_OceanCurrentPierce);
            SteriaCustomEffects["Steria_OceanCurrentGuard"] = typeof(DiceAttackEffect_Steria_OceanCurrentGuard);
            SteriaCustomEffects["Steria_OceanCurrentFarHit"] = typeof(DiceAttackEffect_Steria_OceanCurrentFarHit);

            SteriaCustomEffects["Steria_TideSlash"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaSlash);
            SteriaCustomEffects["Steria_TideHit"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaHit);
            SteriaCustomEffects["Steria_TideGuard"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaGuard);
            SteriaCustomEffects["Steria_TidePierce"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaPierce);
            SteriaCustomEffects["Steria_TideFarHit"] = typeof(DiceAttackEffect_Steria_AnhierTextureSeaFarHit);
            SteriaCustomEffects["Steria_MemorySlash"] = typeof(DiceAttackEffect_Steria_AnhierTextureMemorySlash);
            SteriaCustomEffects["Steria_MemoryHit"] = typeof(DiceAttackEffect_Steria_AnhierTextureMemoryHit);
            SteriaCustomEffects["Steria_MemoryPierce"] = typeof(DiceAttackEffect_Steria_AnhierTextureMemoryPierce);
            SteriaCustomEffects["Steria_MemoryGuard"] = typeof(DiceAttackEffect_Steria_AnhierTextureMemoryGuard);

            // 注册所有自定义特效
            SteriaCustomEffects["Steria_WindSlash"] = typeof(DiceAttackEffect_Steria_WindSlash);
            SteriaCustomEffects["Steria_SlazeyaWindSlash"] = typeof(DiceAttackEffect_Steria_SlazeyaWaterThunderSlash);
            SteriaCustomEffects["Steria_SlazeyaWindHit"] = typeof(DiceAttackEffect_Steria_SlazeyaWaterThunderHit);
            SteriaCustomEffects["Steria_SlazeyaWindPierce"] = typeof(DiceAttackEffect_Steria_SlazeyaWaterThunderPierce);
            SteriaCustomEffects["Steria_SlazeyaWindGuard"] = typeof(DiceAttackEffect_Steria_SlazeyaWindGuard);
            SteriaCustomEffects["Steria_SlazeyaWindFarHit"] = typeof(DiceAttackEffect_Steria_SlazeyaWindFarHit);
            SteriaCustomEffects["Steria_AnhierBlueWhiteSlash"] = typeof(DiceAttackEffect_Steria_AnhierBlueWhiteSlash);
            SteriaCustomEffects["Steria_AnhierBlueWhitePierce"] = typeof(DiceAttackEffect_Steria_AnhierBlueWhitePierce);
            SteriaCustomEffects["Steria_AnhierBlueWhiteHit"] = typeof(DiceAttackEffect_Steria_AnhierBlueWhiteHit);
            SteriaCustomEffects["Steria_AnhierBlueWhiteFarHit"] = typeof(DiceAttackEffect_Steria_AnhierBlueWhiteFarHit);
            SteriaCustomEffects["Steria_ChristashaV2SlashH"] = typeof(DiceAttackEffect_Steria_ChristashaV2SlashH);
            SteriaCustomEffects["Steria_ChristashaV2SlashV"] = typeof(DiceAttackEffect_Steria_ChristashaV2SlashV);
            SteriaCustomEffects["Steria_ChristashaV2PierceNear"] = typeof(DiceAttackEffect_Steria_ChristashaV2PierceNear);
            SteriaCustomEffects["Steria_ChristashaV2PierceFar"] = typeof(DiceAttackEffect_Steria_ChristashaV2PierceFar);
            SteriaCustomEffects["Steria_ChristashaV2Hit"] = typeof(DiceAttackEffect_Steria_ChristashaV2Hit);
            SteriaCustomEffects["Steria_WaterSlash"] = typeof(DiceAttackEffect_Steria_WaterSlash);
            SteriaCustomEffects["Steria_WaterHit"] = typeof(DiceAttackEffect_Steria_WaterHit);
            SteriaCustomEffects["Steria_WaterPenetrate"] = typeof(DiceAttackEffect_Steria_WaterPenetrate);
            SteriaCustomEffects["Steria_WaterFarHit"] = typeof(DiceAttackEffect_Steria_WaterFarHit);
            SteriaCustomEffects["Steria_WaterPierce"] = typeof(DiceAttackEffect_Steria_WaterPierce);
            SteriaCustomEffects["Steria_WaterSurround"] = typeof(DiceAttackEffect_Steria_WaterSurround);
            SteriaCustomEffects["Steria_DarkPurpleSlash"] = typeof(DiceAttackEffect_Steria_DarkPurpleSlash);
            SteriaCustomEffects["VeliaThorn_Z"] = typeof(DiceAttackEffect_VeliaThorn_Z);
            SteriaCustomEffects["Steria_SivierWishGuard"] = typeof(DiceAttackEffect_Steria_SivierWishGuard);

            SteriaLogger.Log($"Initialized {SteriaCustomEffects.Count} custom effects");
            foreach (var kvp in SteriaCustomEffects)
            {
                SteriaLogger.Log($"  - {kvp.Key} => {kvp.Value.Name}");
            }
        }

        [HarmonyPatch(typeof(DiceEffectManager), "CreateBehaviourEffect")]
        [HarmonyPrefix]
        public static bool DiceEffectManager_CreateBehaviourEffect_Prefix(
            DiceEffectManager __instance,
            ref Battle.DiceAttackEffect.DiceAttackEffect __result,
            string resource,
            float scaleFactor,
            BattleUnitView self,
            BattleUnitView target,
            float time = 1f)
        {
            try
            {
                if (string.IsNullOrEmpty(resource))
                {
                    __result = null;
                    return false;
                }

                // 检查是否是我们的自定义特效
                if (SteriaCustomEffects.TryGetValue(resource, out Type effectType))
                {
                    SteriaLogger.Log($"CreateBehaviourEffect: Creating custom effect '{resource}'");

                    GameObject effectObj = new GameObject(resource);
                    var effect = effectObj.AddComponent(effectType) as Battle.DiceAttackEffect.DiceAttackEffect;

                    if (effect != null)
                    {
                        effect.Initialize(self, target, time);
                        effect.SetScale(scaleFactor);
                        __result = effect;
                        SteriaLogger.Log($"CreateBehaviourEffect: Successfully created '{resource}'");
                        return false; // 跳过原方法
                    }
                    else
                    {
                        SteriaLogger.Log($"CreateBehaviourEffect: Failed to create effect component for '{resource}'");
                        UnityEngine.Object.Destroy(effectObj);
                    }
                }
            }
            catch (Exception ex)
            {
                SteriaLogger.Log($"CreateBehaviourEffect ERROR: {ex}");
            }

            return true; // 继续执行原方法
        }

        // --- Patch for 倾诉梦想：远望 (光芒消耗触发) ---
        // 已经有 BattlePlayingCardSlotDetail_SpendCost_Patch，在那里添加触发逻辑

        // --- Patch for 倾诉梦想：幻梦 (书页使用触发) ---
        [HarmonyPatch(typeof(BattlePlayingCardDataInUnitModel), "OnUseCard")]
        [HarmonyPostfix]
        public static void BattlePlayingCardDataInUnitModel_OnUseCard_DreamIllusion_Postfix(BattlePlayingCardDataInUnitModel __instance)
        {
            try
            {
                if (__instance?.owner == null) return;

                // 检查是否有倾诉梦想：幻梦 Buff
                var dreamIllusionBuf = __instance.owner.bufListDetail.GetActivatedBufList()
                    .FirstOrDefault(b => b is BattleUnitBuf_DreamIllusion) as BattleUnitBuf_DreamIllusion;

                if (dreamIllusionBuf != null)
                {
                    dreamIllusionBuf.OnCardUsed();
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Error in DreamIllusion OnUseCard Postfix: {ex}");
            }
        }

        // --- Patch for 倾诉梦想：奉行 (造成伤害触发) 和 神脉：梦之汐 (造成伤害获得流) ---
        [HarmonyPatch(typeof(BattleUnitModel), nameof(BattleUnitModel.TakeDamage))]
        public static class BattleUnitModel_TakeDamage_DreamExecution_Patch
        {
            [HarmonyPostfix]
            public static void Postfix(BattleUnitModel __instance, int v, DamageType type, BattleUnitModel attacker)
            {
                try
                {
                    // 只处理攻击伤害且伤害大于0
                    if (attacker == null || v <= 0 || type != DamageType.Attack) return;

                    // 检查攻击者是否有倾诉梦想：奉行 Buff
                    var dreamExecutionBuf = attacker.bufListDetail.GetActivatedBufList()
                        .FirstOrDefault(b => b is BattleUnitBuf_DreamExecution) as BattleUnitBuf_DreamExecution;

                    if (dreamExecutionBuf != null)
                    {
                        dreamExecutionBuf.OnDamageDealt();
                    }

                    // 检查攻击者是否有 神脉：梦之汐 被动 (每造成10点伤害获得1层流)
                    var passive9002001 = attacker.passiveDetail.PassiveList?
                        .FirstOrDefault(p => p is PassiveAbility_9002001) as PassiveAbility_9002001;

                    if (passive9002001 != null)
                    {
                        passive9002001.OnDamageDealt(v);
                    }

                    // 检查攻击者是否有 斯拉泽雅司流者 被动 (每造成10点伤害获得1层流)
                    var passive9002005 = attacker.passiveDetail.PassiveList?
                        .FirstOrDefault(p => p is PassiveAbility_9002005) as PassiveAbility_9002005;

                    if (passive9002005 != null)
                    {
                        passive9002005.OnDamageDealt(v);
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in DreamExecution TakeDamage Postfix: {ex}");
                }
            }
        }

        // --- Patch for 潮 (Tide) 自动触发机制 ---
        // 简化版：每当施加者有潮时，自动扣1层潮并额外赋予1层buff

        // 认可的buff类型列表（只有这些类型会触发潮加成）
        private static readonly HashSet<KeywordBuf> _tideValidBuffTypes = new HashSet<KeywordBuf>
        {
            // 正面效果
            KeywordBuf.Strength,      // 强壮
            KeywordBuf.Protection,    // 守护
            KeywordBuf.Quickness,     // 迅捷
            KeywordBuf.Endurance,     // 忍耐（加防御骰子威力）
            KeywordBuf.BreakProtection, // 振奋（降低混乱伤害）
            KeywordBuf.DmgUp,         // 威力提升
            KeywordBuf.SlashPowerUp,  // 斩击威力提升
            KeywordBuf.PenetratePowerUp, // 突刺威力提升
            KeywordBuf.HitPowerUp,    // 打击威力提升
            KeywordBuf.DefensePowerUp, // 防御威力提升
            // 负面效果
            KeywordBuf.Bleeding,      // 流血
            KeywordBuf.Burn,          // 烧伤
            KeywordBuf.Weak,          // 虚弱
            KeywordBuf.Vulnerable,    // 易伤
            KeywordBuf.Binding,       // 束缚
            KeywordBuf.Paralysis,     // 麻痹
            KeywordBuf.Decay,         // 腐蚀
            KeywordBuf.Smoke,         // 烟气
        };

        private static readonly HashSet<KeywordBuf> _goldenTideBuffTypes = new HashSet<KeywordBuf>
        {
            KeywordBuf.Strength,
            KeywordBuf.Endurance,
        };

        private static FieldInfo _bufListOwnerField;

        private static BattleUnitModel GetBufListOwner(BattleUnitBufListDetail bufList)
        {
            if (bufList == null) return null;
            if (_bufListOwnerField == null)
            {
                _bufListOwnerField = AccessTools.Field(typeof(BattleUnitBufListDetail), "_self");
            }
            return _bufListOwnerField?.GetValue(bufList) as BattleUnitModel;
        }

        /// <summary>
        /// 简化版潮加成：只要施加者有潮，就扣1层并额外赋予1层
        /// </summary>
        private static int CheckAndConsumeTideSimple(BattleUnitModel giver, KeywordBuf bufType, BattleUnitModel target = null)
        {
            if (giver == null) return 0;
            if (HarmonyHelpers.IsTideEnhancementSuppressed) return 0;

            // 只处理认可的buff类型
            if (!_tideValidBuffTypes.Contains(bufType)) return 0;

            // 获取施加者的潮buff
            BattleUnitBuf_Tide tideBuf = giver.bufListDetail.GetActivatedBufList()
                .FirstOrDefault(b => b is BattleUnitBuf_Tide) as BattleUnitBuf_Tide;

            if (tideBuf == null || tideBuf.stack <= 0) return 0;

            bool hasStephanieProxy = global::DirectiveDreamHelper.HasStephanieProxy(giver);

            // 扣1层潮，额外赋予1层buff
            if (!hasStephanieProxy)
            {
                tideBuf.stack -= 1;
                SteriaLogger.Log($"Tide: Giver {giver.UnitData?.unitData?.name} consumed 1 Tide for {bufType}, remaining = {tideBuf.stack}");
            }
            HarmonyHelpers.NotifyPassivesOnTideConsumed(
                giver,
                1,
                enhancedTarget: target,
                enhancedBufType: bufType,
                enhancedByTide: true);

            if (!hasStephanieProxy && tideBuf.stack <= 0)
            {
                tideBuf.Destroy();
            }

            // 代行-斯蒂芬妮：消耗潮的书页骰子威力+1
            if (hasStephanieProxy)
            {
                giver.currentDiceAction?.currentBehavior?.ApplyDiceStatBonus(new DiceStatBonus { power = 1 });
            }

            return 1; // 固定额外赋予1层
        }

        /// <summary>
        /// 黄金之潮：赋予友方强壮/忍耐时消耗黄金之潮并额外增加层数
        /// </summary>
        private static int CheckAndConsumeGoldenTide(BattleUnitModel giver, BattleUnitModel target, KeywordBuf bufType)
        {
            if (giver == null || target == null) return 0;
            if (HarmonyHelpers.IsTideEnhancementSuppressed) return 0;
            if (!_goldenTideBuffTypes.Contains(bufType)) return 0;
            if (giver.faction != target.faction) return 0;

            global::BattleUnitBuf_GoldenTide golden = giver.bufListDetail.GetActivatedBufList()
                .FirstOrDefault(b => b is global::BattleUnitBuf_GoldenTide) as global::BattleUnitBuf_GoldenTide;

            if (golden == null || golden.stack <= 0) return 0;

            bool isSelf = giver == target;
            int consume = 0;
            int bonus = 0;

            if (isSelf)
            {
                if (golden.stack >= 2)
                {
                    consume = 2;
                    bonus = 2;
                }
                else
                {
                    consume = 1;
                    bonus = 1;
                }
            }
            else
            {
                consume = 1;
                bonus = 1;
            }

            if (golden.stack < consume)
            {
                return 0;
            }

            if (consume <= 0 || bonus <= 0) return 0;

            bool hasStephanieProxy = global::DirectiveDreamHelper.HasStephanieProxy(giver);

            if (!hasStephanieProxy)
            {
                golden.stack -= consume;
                SteriaLogger.Log($"GoldenTide: {giver.UnitData?.unitData?.name} consumed {consume} for {bufType}, bonus={bonus}, remaining={golden.stack}");
            }
            HarmonyHelpers.NotifyPassivesOnTideConsumed(giver, consume, true);

            if (!hasStephanieProxy && golden.stack <= 0)
            {
                golden.Destroy();
            }

            // 代行-斯蒂芬妮：消耗潮的书页骰子威力+1
            if (hasStephanieProxy)
            {
                giver.currentDiceAction?.currentBehavior?.ApplyDiceStatBonus(new DiceStatBonus { power = 1 });
            }

            return bonus;
        }

        /// <summary>
        /// 刷新目标的速度骰子（用于迅捷等需要立即生效的buff）
        /// </summary>
        private static void RefreshSpeedDice(BattleUnitModel target, int addedQuickness)
        {
            if (target == null || target.speedDiceResult == null || addedQuickness <= 0) return;

            try
            {
                // 为每个未破坏的速度骰子增加迅捷加成
                foreach (var speedDice in target.speedDiceResult)
                {
                    if (!speedDice.breaked)
                    {
                        speedDice.value = Mathf.Clamp(speedDice.value + addedQuickness, 1, 999);
                    }
                }

                // 重新排序速度骰子（按值从高到低）
                target.speedDiceResult.Sort((d1, d2) =>
                {
                    if (d1.breaked && d2.breaked) return d2.value.CompareTo(d1.value);
                    if (d1.breaked) return -1;
                    if (d2.breaked) return 1;
                    return d2.value.CompareTo(d1.value);
                });

                // 更新UI
                if (target.view?.speedDiceSetterUI != null)
                {
                    target.view.speedDiceSetterUI.SetSpeedDicesAfterRoll(target.speedDiceResult);
                }

                SteriaLogger.Log($"Tide: Refreshed speed dice for {target.UnitData?.unitData?.name}, added {addedQuickness} Quickness");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Error refreshing speed dice: {ex}");
            }
        }

        // Patch for AddKeywordBufByEtc (下回合生效的buff)
        [HarmonyPatch(typeof(BattleUnitBufListDetail), nameof(BattleUnitBufListDetail.AddKeywordBufByEtc))]
        public static class BattleUnitBufListDetail_AddKeywordBufByEtc_TidePatch
        {
            [HarmonyPrefix]
            public static void Prefix(BattleUnitBufListDetail __instance, KeywordBuf bufType, ref int stack, BattleUnitModel actor)
            {
                try
                {
                    // 调试日志
                    SteriaLogger.Log($"Tide DEBUG: AddKeywordBufByEtc called - bufType={bufType}, stack={stack}, actor={(actor != null ? actor.UnitData?.unitData?.name : "NULL")}");

                    // Burn 会在 AddKeywordBufThisRoundByEtc 中处理，避免重复消耗潮
                    if (bufType == KeywordBuf.Burn) return;

                    if (stack <= 0 || actor == null) return;

                    BattleUnitModel target = GetBufListOwner(__instance);
                    int goldenBonus = CheckAndConsumeGoldenTide(actor, target, bufType);
                    if (goldenBonus > 0)
                    {
                        stack += goldenBonus;
                        SteriaLogger.Log($"GoldenTide: Enhanced {bufType} by {goldenBonus}, new stack = {stack}");
                    }

                    int tideBonus = goldenBonus > 0 ? 0 : CheckAndConsumeTideSimple(actor, bufType, target);
                    if (tideBonus > 0)
                    {
                        stack += tideBonus;
                        SteriaLogger.Log($"Tide: Enhanced {bufType} by {tideBonus}, new stack = {stack}");
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in AddKeywordBufByEtc TidePatch: {ex}");
                }
            }
        }

        // Patch for AddKeywordBufThisRoundByEtc (本回合生效的buff)
        [HarmonyPatch(typeof(BattleUnitBufListDetail), nameof(BattleUnitBufListDetail.AddKeywordBufThisRoundByEtc))]
        public static class BattleUnitBufListDetail_AddKeywordBufThisRoundByEtc_TidePatch
        {
            // 存储潮加成信息，用于Postfix
            private static int _lastTideBonus = 0;
            private static KeywordBuf _lastBufType = KeywordBuf.None;

            [HarmonyPrefix]
            public static void Prefix(BattleUnitBufListDetail __instance, KeywordBuf bufType, ref int stack, BattleUnitModel actor)
            {
                _lastTideBonus = 0;
                _lastBufType = bufType;

                try
                {
                    // 调试日志
                    SteriaLogger.Log($"Tide DEBUG: AddKeywordBufThisRoundByEtc called - bufType={bufType}, stack={stack}, actor={(actor != null ? actor.UnitData?.unitData?.name : "NULL")}");

                    if (stack <= 0 || actor == null) return;

                    BattleUnitModel target = GetBufListOwner(__instance);
                    int goldenBonus = CheckAndConsumeGoldenTide(actor, target, bufType);
                    if (goldenBonus > 0)
                    {
                        stack += goldenBonus;
                        SteriaLogger.Log($"GoldenTide: Enhanced {bufType} (this round) by {goldenBonus}, new stack = {stack}");
                    }

                    int tideBonus = goldenBonus > 0 ? 0 : CheckAndConsumeTideSimple(actor, bufType, target);
                    if (tideBonus > 0)
                    {
                        stack += tideBonus;
                        _lastTideBonus = tideBonus;
                        SteriaLogger.Log($"Tide: Enhanced {bufType} (this round) by {tideBonus}, new stack = {stack}");
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in AddKeywordBufThisRoundByEtc TidePatch Prefix: {ex}");
                }
            }

            [HarmonyPostfix]
            public static void Postfix(BattleUnitBufListDetail __instance, KeywordBuf bufType, int stack)
            {
                try
                {
                    // 如果赋予的是迅捷，刷新速度骰子
                    if (_lastBufType == KeywordBuf.Quickness && stack > 0)
                    {
                        var ownerField = AccessTools.Field(typeof(BattleUnitBufListDetail), "_self");
                        BattleUnitModel target = ownerField?.GetValue(__instance) as BattleUnitModel;
                        if (target != null)
                        {
                            RefreshSpeedDice(target, stack);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in AddKeywordBufThisRoundByEtc TidePatch Postfix: {ex}");
                }
            }
        }

        // Patch for AddKeywordBufByCard (通过卡牌添加的buff，下回合生效)
        [HarmonyPatch(typeof(BattleUnitBufListDetail), nameof(BattleUnitBufListDetail.AddKeywordBufByCard))]
        public static class BattleUnitBufListDetail_AddKeywordBufByCard_TidePatch
        {
            [HarmonyPrefix]
            public static void Prefix(BattleUnitBufListDetail __instance, KeywordBuf bufType, ref int stack, BattleUnitModel actor)
            {
                try
                {
                    // Burn 会在 AddKeywordBufThisRoundByCard 中处理，避免重复消耗潮
                    if (bufType == KeywordBuf.Burn) return;

                    if (stack <= 0 || actor == null) return;

                    BattleUnitModel target = GetBufListOwner(__instance);
                    int goldenBonus = CheckAndConsumeGoldenTide(actor, target, bufType);
                    if (goldenBonus > 0)
                    {
                        stack += goldenBonus;
                        SteriaLogger.Log($"GoldenTide: Enhanced {bufType} (by card) by {goldenBonus}, new stack = {stack}");
                    }

                    int tideBonus = goldenBonus > 0 ? 0 : CheckAndConsumeTideSimple(actor, bufType, target);
                    if (tideBonus > 0)
                    {
                        stack += tideBonus;
                        SteriaLogger.Log($"Tide: Enhanced {bufType} (by card) by {tideBonus}, new stack = {stack}");
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in AddKeywordBufByCard TidePatch: {ex}");
                }
            }
        }

        // Patch for AddKeywordBufThisRoundByCard (通过卡牌添加的buff，本回合生效)
        [HarmonyPatch(typeof(BattleUnitBufListDetail), nameof(BattleUnitBufListDetail.AddKeywordBufThisRoundByCard))]
        public static class BattleUnitBufListDetail_AddKeywordBufThisRoundByCard_TidePatch
        {
            private static KeywordBuf _lastBufType = KeywordBuf.None;

            [HarmonyPrefix]
            public static void Prefix(BattleUnitBufListDetail __instance, KeywordBuf bufType, ref int stack, BattleUnitModel actor)
            {
                _lastBufType = bufType;

                try
                {
                    if (stack <= 0 || actor == null) return;

                    BattleUnitModel target = GetBufListOwner(__instance);
                    int goldenBonus = CheckAndConsumeGoldenTide(actor, target, bufType);
                    if (goldenBonus > 0)
                    {
                        stack += goldenBonus;
                        SteriaLogger.Log($"GoldenTide: Enhanced {bufType} (this round by card) by {goldenBonus}, new stack = {stack}");
                    }

                    int tideBonus = goldenBonus > 0 ? 0 : CheckAndConsumeTideSimple(actor, bufType, target);
                    if (tideBonus > 0)
                    {
                        stack += tideBonus;
                        SteriaLogger.Log($"Tide: Enhanced {bufType} (this round by card) by {tideBonus}, new stack = {stack}");
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in AddKeywordBufThisRoundByCard TidePatch Prefix: {ex}");
                }
            }

            [HarmonyPostfix]
            public static void Postfix(BattleUnitBufListDetail __instance, KeywordBuf bufType, int stack)
            {
                try
                {
                    // 如果赋予的是迅捷，刷新速度骰子
                    if (_lastBufType == KeywordBuf.Quickness && stack > 0)
                    {
                        var ownerField = AccessTools.Field(typeof(BattleUnitBufListDetail), "_self");
                        BattleUnitModel target = ownerField?.GetValue(__instance) as BattleUnitModel;
                        if (target != null)
                        {
                            RefreshSpeedDice(target, stack);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in AddKeywordBufThisRoundByCard TidePatch Postfix: {ex}");
                }
            }
        }

        // --- Patch for 全体友方本幕不消耗流 (随我流向无尽的尽头) ---
        // 存储本幕是否激活了不消耗流效果
        public static bool NoFlowConsumptionActiveThisRound = false;

        // 在幕开始时重置
        [HarmonyPatch(typeof(StageController), "RoundStartPhase_System")]
        public static class StageController_RoundStartPhase_ResetNoFlowConsumption_Patch
        {
            [HarmonyPostfix]
            public static void Postfix()
            {
                NoFlowConsumptionActiveThisRound = false;
                // 重置百川逐风的每幕触发记录
                DiceCardSelfAbility_SlazeyaHundredRiversRepeat.ResetTriggeredOwners();

                // 注意：冷却减少现在由 SteriaEgoCooldownPatches 处理

                _globalFlowPowerBonusThisRound = 0;

                SteriaLogger.Log("Reset NoFlowConsumptionActiveThisRound and HundredRiversRepeat triggers");
                TideConsumptionTracker.CaptureAllUnits();
            }
        }

        // --- Patch for 音段接收：战斗开始时在速度骰初始化后添加反击闪避骰 ---
        [HarmonyPatch(typeof(BattleUnitModel), "OnRoundStart_speedDice")]
        public static class BattleUnitModel_OnRoundStartSpeedDice_SoundSegmentPatch
        {
            [HarmonyPostfix]
            public static void Postfix(BattleUnitModel __instance)
            {
                try
                {
                    if (__instance == null || __instance.IsDead())
                    {
                        return;
                    }

                    PassiveAbility_9007005 passive = __instance.passiveDetail?.PassiveList
                        ?.FirstOrDefault(p => p is PassiveAbility_9007005) as PassiveAbility_9007005;
                    if (passive == null)
                    {
                        return;
                    }

                    passive.TryApplySoundSegmentDiceOnRoundStart();
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error applying SoundSegment dice after speed dice: {ex}");
                }
            }
        }

        [HarmonyPatch(typeof(StageController), "RoundEndPhase_TheLast")]
        public static class StageController_RoundEndPhase_TheLast_TideFlushPatch
        {
            [HarmonyPrefix]
            public static void Prefix()
            {
                try
                {
                    TideConsumptionTracker.FlushUnnotified();
                    BattleUnitBuf_ChristashaExtend.ClearLockedActions();
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error flushing unnotified Tide consumption: {ex}");
                }
            }
        }

        [HarmonyPatch(typeof(BattleUnitModel), "IsTargetableUnit")]
        public static class BattleUnitModel_IsTargetableUnit_PhantomDreamPatch
        {
            [HarmonyPostfix]
            public static void Postfix(BattleDiceCardModel card, BattleUnitModel actor, BattleUnitModel target, int targetDiceIdx, ref bool __result)
            {
                try
                {
                    if (!__result && HarmonyHelpers.CanTargetAllyWithPhantomDream(card, actor, target, targetDiceIdx))
                    {
                        __result = true;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] PhantomDream target patch error: {ex}");
                }
            }
        }

        [HarmonyPatch(typeof(BattlePlayingCardSlotDetail), "AddCard")]
        public static class BattlePlayingCardSlotDetail_AddCard_ExtendLockPatch
        {
            [HarmonyPrefix]
            public static bool Prefix(BattlePlayingCardSlotDetail __instance, BattleDiceCardModel card, BattleUnitModel target, int targetSlot, bool isEnemyAuto)
            {
                try
                {
                    if (isEnemyAuto || __instance == null)
                    {
                        return true;
                    }

                    FieldInfo selfField = AccessTools.Field(typeof(BattlePlayingCardSlotDetail), "_self");
                    BattleUnitModel owner = selfField?.GetValue(__instance) as BattleUnitModel;
                    if (owner == null)
                    {
                        return true;
                    }

                    int slot = owner.cardOrder;
                    if (slot < 0 || slot >= __instance.cardAry.Count)
                    {
                        return true;
                    }

                    BattlePlayingCardDataInUnitModel existing = __instance.cardAry[slot];
                    if (BattleUnitBuf_ChristashaExtend.IsLockedAction(existing))
                    {
                        return false;
                    }

                    if (HarmonyHelpers.TryResolvePhantomDreamTransfer(owner, card, target, targetSlot))
                    {
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Extend lock AddCard patch error: {ex}");
                }

                return true;
            }
        }

        [HarmonyPatch(typeof(LOR_BattleUnit_UI.SpeedDiceUI), "DeselectCard")]
        public static class SpeedDiceUI_DeselectCard_ExtendLockPatch
        {
            [HarmonyPrefix]
            public static bool Prefix(LOR_BattleUnit_UI.SpeedDiceUI __instance)
            {
                try
                {
                    BattlePlayingCardDataInUnitModel card = __instance?.CardInDice;
                    if (BattleUnitBuf_ChristashaExtend.IsLockedAction(card))
                    {
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Extend lock Deselect patch error: {ex}");
                }

                return true;
            }
        }

        // 在战斗结束时清除所有冷却状态和临时数据
        [HarmonyPatch(typeof(StageController), "EndBattle")]
        public static class StageController_EndBattle_ClearCooldowns_Patch
        {
            [HarmonyPostfix]
            public static void Postfix()
            {
                try
                {
                    // 注意：冷却清除现在由 SteriaEgoCooldownPatches 处理
                    // 清除随我流向无尽的尽头的威力加成存储
                    DiceCardSelfAbility_SlazeyaEndlessFlow.ClearPowerBonuses();
                    TideConsumptionTracker.Reset();
                    SteriaLogger.Log("Battle ended: Cleared power bonuses");
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error clearing data on battle end: {ex}");
                }
            }
        }

        // --- Patch for [迅攻]：速度更快时不改变目标并避免拼点 ---
        [HarmonyPatch(typeof(BattleUnitModel), nameof(BattleUnitModel.CanChangeAttackTarget))]
        public static class BattleUnitModel_CanChangeAttackTarget_RapidAssaultPatch
        {
            [HarmonyPrefix]
            public static bool Prefix(BattleUnitModel __instance, BattleUnitModel target, int myIndex, int targetIndex, ref bool __result)
            {
                try
                {
                    // 致盲：无法更改目标
                    if (__instance?.bufListDetail != null)
                    {
                        bool hasBlinding = __instance.bufListDetail.GetActivatedBufList()
                            .Any(buf => buf is BattleUnitBuf_Blinding && buf.stack > 0);
                        if (hasBlinding)
                        {
                            __result = false;
                            SteriaLogger.Log($"Blinding blocked target change: {__instance.UnitData?.unitData?.name}");
                            return false;
                        }
                    }

                    if (__instance?.cardSlotDetail?.cardAry == null || target == null)
                    {
                        return true;
                    }

                    if (myIndex < 0 || myIndex >= __instance.cardSlotDetail.cardAry.Count)
                    {
                        return true;
                    }

                    BattlePlayingCardDataInUnitModel myCard = __instance.cardSlotDetail.cardAry[myIndex];
                    if (myCard == null || !HarmonyHelpers.HasRapidAssaultKeyword(myCard))
                    {
                        return true;
                    }

                    if (target.cardSlotDetail?.cardAry == null || targetIndex < 0 || targetIndex >= target.cardSlotDetail.cardAry.Count)
                    {
                        return true;
                    }

                    int mySpeed = myCard.speedDiceResultValue > 0
                        ? myCard.speedDiceResultValue
                        : __instance.GetSpeedDiceResult(myIndex).value;

                    int targetSpeed = -1;
                    BattlePlayingCardDataInUnitModel targetCard = target.cardSlotDetail.cardAry[targetIndex];
                    if (targetCard != null && targetCard.speedDiceResultValue > 0)
                    {
                        targetSpeed = targetCard.speedDiceResultValue;
                    }
                    else if (target.speedDiceResult != null && targetIndex < target.speedDiceResult.Count)
                    {
                        targetSpeed = target.GetSpeedDiceResult(targetIndex).value;
                    }

                    if (mySpeed <= 0 || targetSpeed <= 0)
                    {
                        return true;
                    }

                    if (mySpeed > targetSpeed)
                    {
                        __result = false;
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] RapidAssault CanChangeAttackTarget patch error: {ex}");
                }

                return true;
            }
        }

        [HarmonyPatch(typeof(StageController), "StartParrying")]
        public static class StageController_StartParrying_RapidAssaultPatch
        {
            private static readonly MethodInfo _startActionMethod =
                AccessTools.Method(typeof(StageController), "StartAction", new Type[] { typeof(BattlePlayingCardDataInUnitModel) });

            [HarmonyPrefix]
            public static bool Prefix(StageController __instance, BattlePlayingCardDataInUnitModel cardA, BattlePlayingCardDataInUnitModel cardB)
            {
                try
                {
                    BattlePlayingCardDataInUnitModel rapidCard = null;
                    if (HarmonyHelpers.IsRapidAssaultFaster(cardA, cardB))
                    {
                        rapidCard = cardA;
                    }
                    else if (HarmonyHelpers.IsRapidAssaultFaster(cardB, cardA))
                    {
                        rapidCard = cardB;
                    }

                    if (rapidCard == null || rapidCard.target == null)
                    {
                        return true;
                    }

                    if (_startActionMethod == null)
                    {
                        SteriaLogger.LogWarning("RapidAssault: StartAction method not found, falling back to parrying.");
                        return true;
                    }

                    _startActionMethod.Invoke(__instance, new object[] { rapidCard });
                    SteriaLogger.Log($"RapidAssault: One-side action by {rapidCard.owner?.UnitData?.unitData?.name}");
                    return false;
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] RapidAssault StartParrying patch error: {ex}");
                }

                return true;
            }
        }

        // --- Patch for 汐火联星: 连续2次同目标 ---
        [HarmonyPatch(typeof(StageController), "StartAction")]
        public static class StageController_StartAction_TwinStarLockPatch
        {
            [HarmonyPrefix]
            public static void Prefix(StageController __instance, BattlePlayingCardDataInUnitModel card)
            {
                try
                {
                    if (card?.owner == null) return;
                    if (!IsChristashaTwinStar(card) && !(card.cardAbility is DiceCardSelfAbility_ChristashaTwinStar)) return;

                    BattleUnitModel owner = card.owner;
                    BattleUnitBuf_ChristashaTwinStarLock lockBuf = owner.bufListDetail?.GetActivatedBufList()
                        .FirstOrDefault(b => b is BattleUnitBuf_ChristashaTwinStarLock) as BattleUnitBuf_ChristashaTwinStarLock;

                    if (lockBuf == null || lockBuf.remaining <= 0 || lockBuf.target == null || lockBuf.target.IsDead() || lockBuf.target.IsBreakLifeZero())
                    {
                        if (card.target == null) return;
                        lockBuf = new BattleUnitBuf_ChristashaTwinStarLock
                        {
                            target = card.target,
                            remaining = 2
                        };
                        owner.bufListDetail.AddBuf(lockBuf);
                    }
                    else
                    {
                        if (card.target != lockBuf.target)
                        {
                            card.target = lockBuf.target;
                            card.earlyTarget = lockBuf.target;
                            int tslot = 0;
                            if (lockBuf.target.speedDiceResult != null && lockBuf.target.speedDiceResult.Count > 0)
                            {
                                tslot = Math.Min(Math.Max(0, card.targetSlotOrder), lockBuf.target.speedDiceResult.Count - 1);
                            }
                            card.targetSlotOrder = tslot;
                            card.earlyTargetOrder = tslot;
                            card.ResetCardQueue();
                        }
                    }

                    lockBuf.remaining = Math.Max(0, lockBuf.remaining - 1);
                    if (lockBuf.remaining <= 0)
                    {
                        lockBuf.Destroy();
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] TwinStar lock patch error: {ex}");
                }
            }
        }

        // --- Patch for 荆棘攻击移除机制 ---
        // 当拥有荆棘的单位进行单方面攻击时，移除1层荆棘
        [HarmonyPatch(typeof(BattleOneSidePlayManager), "StartOneSidePlay")]
        public static class BattleOneSidePlayManager_StartOneSidePlay_ThornPatch
        {
            [HarmonyPostfix]
            public static void Postfix(BattleOneSidePlayManager __instance, BattlePlayingCardDataInUnitModel card)
            {
                try
                {
                    if (card?.owner == null) return;

                    BattleUnitModel attacker = card.owner;

                    // 检查攻击者是否有荆棘
                    BattleUnitBuf_Thorn thornBuf = attacker.bufListDetail?.GetActivatedBufList()
                        ?.FirstOrDefault(b => b is BattleUnitBuf_Thorn) as BattleUnitBuf_Thorn;

                    if (thornBuf != null && thornBuf.stack > 0)
                    {
                        thornBuf.OnOneSidedAttack();
                        SteriaLogger.Log($"Thorn: {attacker.UnitData?.unitData?.name} attacked, Thorn reduced");
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[Steria] Error in BattleOneSidePlayManager Thorn patch: {ex}");
                }
            }
        }

    } // End of HarmonyPatches class

    /// <summary>
    /// Harmony补丁：修复mod核心书页的OnlyCard无法正确加载mod卡牌的问题
    /// 原版游戏使用int类型的ID，无法识别mod卡牌（需要完整的LorId包含workshopID）
    /// </summary>
    [HarmonyPatch(typeof(BookModel), "SetXmlInfo")]
    public static class BookModel_SetXmlInfo_OnlyCardFix_Patch
    {
        // Steria mod的workshopID
        private const string STERIA_WORKSHOP_ID = "SteriaBuilding";

        [HarmonyPostfix]
        [HarmonyAfter("LOR.BaseMod")]
        public static void Postfix(BookModel __instance, BookXmlInfo classInfo)
        {
            try
            {
                // 按包标识限定范围，避免核心书页改号后专属书页失效。
                if (__instance == null || classInfo?.EquipEffect == null ||
                    classInfo.id.packageId != STERIA_WORKSHOP_ID)
                {
                    return;
                }

                // 保留原版和BaseMod已加载的专属书页。
                var onlyCards = __instance.GetOnlyCards();
                if (onlyCards == null) return;

                // 遍历OnlyCard列表，尝试使用mod的workshopID加载卡牌
                foreach (int cardId in classInfo.EquipEffect.OnlyCard)
                {
                    LorId modCardId = new LorId(classInfo.id.packageId, cardId);
                    // 必须比较完整LorId：原版查找产生的同号错误占位页不算已加载。
                    bool alreadyLoaded = onlyCards.Exists(x => !x.isError && x.id == modCardId);
                    if (alreadyLoaded) continue;

                    // 尝试使用mod的workshopID加载卡牌
                    DiceCardXmlInfo cardItem = ItemXmlDataList.instance.GetCardItem(modCardId, true);

                    if (cardItem != null && !cardItem.isError && cardItem.id == modCardId)
                    {
                        onlyCards.RemoveAll(x => x.isError && x.id.id == cardId &&
                            (x.id.IsBasic() || x.id == modCardId));
                        onlyCards.Add(cardItem);
                        SteriaLogger.Log($"OnlyCardFix: Added mod card {modCardId} to book {classInfo.id}");
                    }
                    else
                    {
                        SteriaLogger.Log($"OnlyCardFix: Failed to find mod card {modCardId} for book {classInfo.id}");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] OnlyCardFix error: {ex}");
            }
        }
    }

    // ==============================================================
    // 乐章型骰子（Music dice）补丁集合
    // ==============================================================

    /// <summary>
    /// 乐章型骰子伤害结算：
    ///   - 进入 GiveDamage 前压入 MusicDamageContext
    ///   - 上下文激活时，BookModel.GetResistRate 会按"先体力(1.0)、再混乱(1.25)"返回固定乘数，
    ///     而非按敌人 Slash/Penetrate/Hit 抗性。
    /// </summary>
    [HarmonyPatch(typeof(BattleDiceBehavior), nameof(BattleDiceBehavior.GiveDamage))]
    public static class BattleDiceBehavior_GiveDamage_MusicDicePatch
    {
        [HarmonyPrefix]
        public static void Prefix(BattleDiceBehavior __instance, BattleUnitModel target)
        {
            try
            {
                if (target != null && MusicDiceSystem.IsMusicDiceBehaviour(__instance))
                {
                    MusicDamageContext.Enter(target);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music dice GiveDamage Prefix error: {ex}");
            }
        }

        [HarmonyPostfix]
        public static void Postfix(BattleDiceBehavior __instance, BattleUnitModel target)
        {
            try
            {
                if (target != null && MusicDiceSystem.IsMusicDiceBehaviour(__instance))
                {
                    MusicDamageContext.Exit();
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music dice GiveDamage Postfix error: {ex}");
            }
        }
    }

    /// <summary>
    /// 替换 BookModel.GetResistRate 的返回值：
    ///   - 处于 MusicDamageContext 时，第 1 次调用 = 体力(1.0×乐章抗性)，第 2 次 = 混乱(1.25×乐章抗性)
    ///   - 其余情况走原逻辑
    /// </summary>
    [HarmonyPatch(typeof(BookModel), nameof(BookModel.GetResistRate))]
    public static class BookModel_GetResistRate_MusicDicePatch
    {
        [HarmonyPrefix]
        public static bool Prefix(AtkResist atkResist, ref float __result)
        {
            if (!MusicDamageContext.IsActive)
            {
                return true;
            }

            float? overrideRate = MusicDamageContext.NextResistRate();
            if (overrideRate.HasValue)
            {
                __result = overrideRate.Value;
                return false;
            }
            return true;
        }
    }

    /// <summary>
    /// 普通近战的伤害数字在伤害计算完成后才由 PrintDamage 回放。根据当前两侧
    /// BattleCardBehaviourResult 建立只读的展示上下文，使回放不依赖已经前移的 currentBehavior。
    /// </summary>
    [HarmonyPatch(typeof(RencounterManager), "PrintDamage")]
    public static class RencounterManager_PrintDamage_MusicDicePatch
    {
        private static readonly FieldInfo LibrarianResultField =
            AccessTools.Field(typeof(RencounterManager), "_currentLibrarianBehaviourResult");
        private static readonly FieldInfo EnemyResultField =
            AccessTools.Field(typeof(RencounterManager), "_currentEnemyBehaviourResult");
        private static readonly FieldInfo LibrarianViewField =
            AccessTools.Field(typeof(RencounterManager), "_librarian");
        private static readonly FieldInfo EnemyViewField =
            AccessTools.Field(typeof(RencounterManager), "_enemy");

        [HarmonyPrefix]
        public static void Prefix(RencounterManager __instance, out MusicDamagePlaybackContext.Scope __state)
        {
            __state = null;
            try
            {
                BattleCardBehaviourResult librarianResult =
                    LibrarianResultField?.GetValue(__instance) as BattleCardBehaviourResult;
                BattleCardBehaviourResult enemyResult =
                    EnemyResultField?.GetValue(__instance) as BattleCardBehaviourResult;
                BattleUnitView librarian = LibrarianViewField?.GetValue(__instance) as BattleUnitView;
                BattleUnitView enemy = EnemyViewField?.GetValue(__instance) as BattleUnitView;

                bool librarianMusic = IsMusicAttackResult(librarianResult);
                bool enemyMusic = IsMusicAttackResult(enemyResult);
                __state = MusicDamagePlaybackContext.Enter(
                    librarianMusic ? librarian?.model : null,
                    librarianMusic ? enemy?.model : null,
                    enemyMusic ? enemy?.model : null,
                    enemyMusic ? librarian?.model : null);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music PrintDamage Prefix error: {ex}");
                __state?.Dispose();
                __state = null;
            }
        }

        [HarmonyPostfix]
        public static void Postfix(MusicDamagePlaybackContext.Scope __state)
        {
            __state?.Dispose();
        }

        [HarmonyFinalizer]
        public static Exception Finalizer(Exception __exception, MusicDamagePlaybackContext.Scope __state)
        {
            // Postfix 与 Finalizer 都可能执行；Scope.Dispose 是幂等的。
            __state?.Dispose();
            return __exception;
        }

        private static bool IsMusicAttackResult(BattleCardBehaviourResult result)
        {
            DiceBehaviour behaviour = result?.behaviourRawData;
            return MusicDiceSystem.IsMusicCard(result?.cardModel)
                && MusicDiceVisuals.IsMusicUiBehaviour(behaviour);
        }
    }

    [HarmonyPatch(typeof(AttackEffectManager), nameof(AttackEffectManager.CreateDamagedTextEffect))]
    public static class AttackEffectManager_CreateDamagedTextEffect_MusicDicePatch
    {
        public sealed class MusicDamageTextState
        {
            public bool ShouldApply;
            public HashSet<DamageTextEffect> Existing;
        }

        [HarmonyPrefix]
        public static void Prefix(
            BehaviourDetail detail,
            BattleUnitModel unit,
            BattleUnitModel attacker,
            out MusicDamageTextState __state)
        {
            __state = null;
            try
            {
                bool isAttackDetail = detail == BehaviourDetail.Slash
                    || detail == BehaviourDetail.Penetrate
                    || detail == BehaviourDetail.Hit;
                bool isDirectMusicDamage = MusicDamageContext.IsActive;
                bool isMusicPlayback = MusicDamagePlaybackContext.Matches(attacker, unit);
                if ((!isDirectMusicDamage && !isMusicPlayback) || !isAttackDetail)
                {
                    return;
                }

                __state = new MusicDamageTextState
                {
                    ShouldApply = true,
                    Existing = new HashSet<DamageTextEffect>()
                };

                Transform root = unit?.view?.damageTextEffectRoot;
                if (root == null)
                {
                    return;
                }

                DamageTextEffect[] before = root.GetComponentsInChildren<DamageTextEffect>(true);
                foreach (DamageTextEffect effect in before)
                {
                    if (effect != null)
                    {
                        __state.Existing.Add(effect);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music damage text Prefix error: {ex}");
                __state = null;
            }
        }

        [HarmonyPostfix]
        public static void Postfix(BattleUnitModel unit, AtkResist atkResist, int colorIdx, MusicDamageTextState __state)
        {
            try
            {
                if (__state == null || !__state.ShouldApply)
                {
                    return;
                }

                Transform root = unit?.view?.damageTextEffectRoot;
                if (root == null)
                {
                    return;
                }

                DamageTextEffect[] effects = root.GetComponentsInChildren<DamageTextEffect>(true);
                DamageTextEffect selected = null;
                foreach (DamageTextEffect effect in effects)
                {
                    if (effect != null && (__state.Existing == null || !__state.Existing.Contains(effect)))
                    {
                        selected = effect;
                    }
                }

                // Vanilla instantiates a new effect per call. Never restyle a previous hit if creation was skipped.
                MusicDiceVisuals.ApplyOnDamageText(selected, atkResist, colorIdx);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music damage text Postfix error: {ex}");
            }
        }
    }

    /// <summary>
    /// 乐章型骰子与防御型骰子拼点时，跳过拼点：
    ///   - 乐章方强制判定为胜方
    ///   - 防御方"当前防御骰"被移动到本张书页骰子队列末尾（不消耗、推后使用）
    ///
    /// 时机说明：Decision() 末尾就直接调用 ActionPhase()，因此挂 Decision Postfix 会太晚
    /// （vanilla ActionPhase 已按错误胜负执行了动作）。改在 ActionPhase Prefix 里改写胜负字段，
    /// 同时把防御方的 currentBehavior 临时挪空，让 vanilla ActionPhaseAtkVSDfn 走"无防御方"分支，
    /// 直接给乐章方造成伤害。
    /// </summary>
    [HarmonyPatch(typeof(BattleParryingManager), "ActionPhase")]
    public static class BattleParryingManager_ActionPhase_MusicSkipPatch
    {
        [HarmonyPrefix]
        public static void Prefix(BattleParryingManager __instance)
        {
            try
            {
                MusicDiceClashRouter.TryRouteMusicVsDefense(__instance);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music vs Defense skip patch error: {ex}");
            }
        }
    }

    /// <summary>
    /// EndAction 末尾会调用 CheckParryingEnd 进入下一轮 Decision。
    /// 在它之前把被乐章跳过拼点的防御骰从队列推回 currentBehavior，
    /// 这样下一轮 Decision 看到的就是新的当前骰，被推后的那颗已挪到队列末尾。
    /// </summary>
    [HarmonyPatch(typeof(BattleParryingManager), "CheckParryingEnd")]
    public static class BattleParryingManager_CheckParryingEnd_MusicDicePatch
    {
        [HarmonyPrefix]
        public static void Prefix()
        {
            try
            {
                MusicDiceClashRouter.OnBeforeCheckParryingEnd();
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music vs Defense CheckParryingEnd prefix error: {ex}");
            }
        }
    }

    /// <summary>
    /// 处理"乐章型骰子 vs 防御型骰子"的特殊拼点路由：
    ///   1. 检测当前 Decision 阶段两侧骰子是否构成 音乐 vs 防御
    ///   2. 强制把乐章方设为胜方、防御方设为败方
    ///   3. 立刻把防御方的 currentBehavior 重新入队到本张书页末尾（不销毁），并清空 currentBehavior
    ///      这样接下来 ActionPhaseAtkVSDfn 会走"防御侧无骰子"分支，直接由攻击侧给伤害。
    /// </summary>
    internal static class MusicDiceClashRouter
    {
        /// <summary>
        /// 当前正在等待"在 CheckParryingEnd 之前推进队列"的防御方书页。
        /// 用 ThreadStatic 防止跨线程串扰；正常游戏单线程，仅作保险。
        /// </summary>
        [ThreadStatic] private static BattlePlayingCardDataInUnitModel _pendingDefenseCard;

        public static void TryRouteMusicVsDefense(BattleParryingManager mgr)
        {
            if (mgr == null)
            {
                return;
            }

            var enemyTeam = AccessTools.Field(typeof(BattleParryingManager), "_teamEnemy")?.GetValue(mgr)
                as BattleParryingManager.ParryingTeam;
            var libTeam = AccessTools.Field(typeof(BattleParryingManager), "_teamLibrarian")?.GetValue(mgr)
                as BattleParryingManager.ParryingTeam;
            if (enemyTeam == null || libTeam == null)
            {
                return;
            }
            if (!enemyTeam.DiceExists() || !libTeam.DiceExists())
            {
                return;
            }

            var enemyBehavior = enemyTeam.playingCard?.currentBehavior;
            var libBehavior = libTeam.playingCard?.currentBehavior;
            if (enemyBehavior == null || libBehavior == null)
            {
                return;
            }

            bool enemyIsMusic = MusicDiceSystem.IsMusicDiceBehaviour(enemyBehavior);
            bool libIsMusic = MusicDiceSystem.IsMusicDiceBehaviour(libBehavior);
            bool enemyIsDefense = enemyTeam.GetParryingDiceType() == BattleParryingManager.ParryingDiceType.Defense;
            bool libIsDefense = libTeam.GetParryingDiceType() == BattleParryingManager.ParryingDiceType.Defense;

            BattleParryingManager.ParryingTeam musicTeam = null;
            BattleParryingManager.ParryingTeam defenseTeam = null;
            BattleParryingManager.ParryingDecisionResult forcedResult;

            if (enemyIsMusic && libIsDefense)
            {
                musicTeam = enemyTeam;
                defenseTeam = libTeam;
                forcedResult = BattleParryingManager.ParryingDecisionResult.WinEnemy;
            }
            else if (libIsMusic && enemyIsDefense)
            {
                musicTeam = libTeam;
                defenseTeam = enemyTeam;
                forcedResult = BattleParryingManager.ParryingDecisionResult.WinLibrarian;
            }
            else
            {
                return;
            }

            // 1) 改写胜负 / 攻防字段，让 vanilla ActionPhase 进入 Atk vs Dfn 分支。
            ForceClashResult(mgr, forcedResult, musicTeam, defenseTeam);

            // 2) 把防御方当前骰挪到队列末尾，并暂时清空 currentBehavior，
            //    让 vanilla ActionPhaseAtkVSDfn 走 "!DiceExists" 路径，直接对单位造成乐章伤害。
            BattlePlayingCardDataInUnitModel deferredCard = DeferDefenseBehavior(defenseTeam);

            // 3) 记下要在下一次 CheckParryingEnd 之前推进的书页。
            _pendingDefenseCard = deferredCard;

            SteriaLogger.Log($"MusicDice clash skip: music={GetUnitName(musicTeam)}, defense={GetUnitName(defenseTeam)}");
        }

        /// <summary>
        /// 在 vanilla CheckParryingEnd 真正运行前，让被推迟的防御方书页前进一格，
        /// 这样下一次 Decision 看到的是队列里"原本应该是下一颗"的骰子；
        /// 而我们刚才挪到队尾的那颗会自然在更后面的回合再次掷骰。
        /// </summary>
        public static void OnBeforeCheckParryingEnd()
        {
            BattlePlayingCardDataInUnitModel card = _pendingDefenseCard;
            if (card == null)
            {
                return;
            }
            _pendingDefenseCard = null;

            // 若单位已死 / extinction / 无可用骰，跳过即可（NextDice 自身也会判断队列）。
            try
            {
                card.NextDice();
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music vs Defense deferred NextDice error: {ex}");
            }
        }

        /// <summary>
        /// 把防御方当前的 currentBehavior 推到本张书页骰子队列末尾，并清空 currentBehavior /
        /// currentBehaviorUI（让 DiceExists() 暂时返回 false）。
        /// 不调用 DestroyDice、不修改 isUsed 之外的字段，骰子稍后会被 NextDice 重新取出来再次掷点。
        /// </summary>
        private static BattlePlayingCardDataInUnitModel DeferDefenseBehavior(BattleParryingManager.ParryingTeam defenseTeam)
        {
            BattlePlayingCardDataInUnitModel playingCard = defenseTeam?.playingCard;
            BattleDiceBehavior behavior = playingCard?.currentBehavior;
            if (playingCard == null || behavior == null)
            {
                return null;
            }

            // RollDice 会把 isUsed 置为 true；这里复位让它能再次进入掷骰流程。
            behavior.isUsed = false;
            playingCard.AddDice(behavior);
            playingCard.currentBehavior = null;
            playingCard.currentBehaviorUI = null;
            return playingCard;
        }

        private static void ForceClashResult(
            BattleParryingManager mgr,
            BattleParryingManager.ParryingDecisionResult result,
            BattleParryingManager.ParryingTeam winner,
            BattleParryingManager.ParryingTeam loser)
        {
            AccessTools.Field(typeof(BattleParryingManager), "_decisionResult")?.SetValue(mgr, result);
            AccessTools.Field(typeof(BattleParryingManager), "_currentWinnerTeam")?.SetValue(mgr, winner);
            AccessTools.Field(typeof(BattleParryingManager), "_currentLoserTeam")?.SetValue(mgr, loser);
            AccessTools.Field(typeof(BattleParryingManager), "_currentAttackerTeam")?.SetValue(mgr, winner);
            AccessTools.Field(typeof(BattleParryingManager), "_currentDefenderTeam")?.SetValue(mgr, loser);
        }

        private static string GetUnitName(BattleParryingManager.ParryingTeam team)
        {
            try
            {
                return team?.unit?.UnitData?.unitData?.name ?? "?";
            }
            catch
            {
                return "?";
            }
        }
    }

    /// <summary>
    /// 拦截原版"强壮"对乐章型骰子的威力加成。
    /// </summary>
    [HarmonyPatch(typeof(BattleUnitBuf_strength), nameof(BattleUnitBuf_strength.BeforeRollDice))]
    public static class BattleUnitBuf_strength_MusicDicePatch
    {
        [HarmonyPrefix]
        public static bool Prefix(BattleDiceBehavior behavior)
        {
            return !MusicDiceSystem.IsMusicDiceBehaviour(behavior);
        }
    }

    /// <summary>
    /// 拦截原版"忍耐"对乐章型骰子的影响。乐章型骰子不是防御骰，理论上不会被命中，
    /// 但为契合需求显式忽略，避免未来扩展时出现意外。
    /// </summary>
    [HarmonyPatch(typeof(BattleUnitBuf_endurance), nameof(BattleUnitBuf_endurance.BeforeRollDice))]
    public static class BattleUnitBuf_endurance_MusicDicePatch
    {
        [HarmonyPrefix]
        public static bool Prefix(BattleDiceBehavior behavior)
        {
            return !MusicDiceSystem.IsMusicDiceBehaviour(behavior);
        }
    }

    /// <summary>
    /// 拦截"进攻型骰子伤害增加"类原版 buff（dmgUp / slash / hit / penetrate / allPowerUp 等），
    /// 让乐章型骰子不被原版攻击系威力 / 伤害加成增强。
    /// </summary>
    [HarmonyPatch(typeof(BattleUnitBuf_dmgUp), nameof(BattleUnitBuf_dmgUp.BeforeGiveDamage))]
    public static class BattleUnitBuf_dmgUp_MusicDicePatch
    {
        [HarmonyPrefix]
        public static bool Prefix(BattleDiceBehavior behavior)
        {
            return !MusicDiceSystem.IsMusicDiceBehaviour(behavior);
        }
    }

    [HarmonyPatch(typeof(BattleUnitBuf_slashPowerUp), nameof(BattleUnitBuf_slashPowerUp.BeforeRollDice))]
    public static class BattleUnitBuf_slashPowerUp_MusicDicePatch
    {
        [HarmonyPrefix]
        public static bool Prefix(BattleDiceBehavior behavior)
        {
            return !MusicDiceSystem.IsMusicDiceBehaviour(behavior);
        }
    }

    [HarmonyPatch(typeof(BattleUnitBuf_hitPowerUp), nameof(BattleUnitBuf_hitPowerUp.BeforeRollDice))]
    public static class BattleUnitBuf_hitPowerUp_MusicDicePatch
    {
        [HarmonyPrefix]
        public static bool Prefix(BattleDiceBehavior behavior)
        {
            return !MusicDiceSystem.IsMusicDiceBehaviour(behavior);
        }
    }

    [HarmonyPatch(typeof(BattleUnitBuf_penetratePowerUp), nameof(BattleUnitBuf_penetratePowerUp.BeforeRollDice))]
    public static class BattleUnitBuf_penetratePowerUp_MusicDicePatch
    {
        [HarmonyPrefix]
        public static bool Prefix(BattleDiceBehavior behavior)
        {
            return !MusicDiceSystem.IsMusicDiceBehaviour(behavior);
        }
    }

    // 注：`BattleUnitBuf_AllPowerUp`（"所有骰子威力提升"）是非指定型加成，
    // 按设计应当能正常生效到乐章型骰子。此处不再拦截。
    // 类似地，影响 min/max 的书页效果（渐强 / 渐弱）以及其他"全骰子向"加成
    // 都不在 *_MusicDicePatch 拦截范围之内。

    // 注：以前这里有一个 BattleDiceBehavior_ApplyDiceStatBonus_MusicDicePatch 全局拦截器，
    // 会无脑把乐章骰子的 power/dmg/dmgRate/breakRate 清零；现已移除，让本 mod 的骰子加成
    // （流 +N、梦 -1、潮、潮之启示等）都能正常作用在乐章骰子上。
    // 原版"强壮 / 忍耐 / 进攻骰威力提升 / 伤害+"等仍由各自专属的 *_MusicDicePatch
    // （Prefix return false）在调用 ApplyDiceStatBonus 之前就被拦截。

    // --- 乐章骰 UI: vanilla silhouettes and per-behaviour ownership ---
    [HarmonyPatch(typeof(BattleSimpleActionUI_Dice), "PrepareDice", new Type[] { typeof(List<BattleCardBehaviourResult>) })]
    public static class BattleSimpleActionUI_Dice_PrepareDice_List_MusicStyle_Patch
    {
        [HarmonyPrefix]
        public static void Prefix(BattleSimpleActionUI_Dice __instance, List<BattleCardBehaviourResult> battleDiceBehaviorResults)
        {
            BattleCardBehaviourResult first = battleDiceBehaviorResults != null && battleDiceBehaviorResults.Count > 0
                ? battleDiceBehaviorResults[0] : null;
            MusicDiceVisuals.PrepareAction(__instance, first?.cardModel, first?.behaviourRawData);
        }
    }

    [HarmonyPatch(typeof(BattleSimpleActionUI_Dice), "PrepareDice", new Type[] { typeof(BattleDiceBehaviourUI) })]
    public static class BattleSimpleActionUI_Dice_PrepareDice_Behavior_MusicStyle_Patch
    {
        [HarmonyPrefix]
        public static void Prefix(BattleSimpleActionUI_Dice __instance, BattleDiceBehaviourUI b)
        {
            MusicDiceVisuals.PrepareAction(__instance, b?.cardmodel, b?.behaviourInCard);
        }
    }

    [HarmonyPatch(typeof(BattleSimpleActionUI_Dice), "PrepareDice", new Type[] { typeof(BattleDiceBehavior) })]
    public static class BattleSimpleActionUI_Dice_PrepareDice_Runtime_MusicStyle_Patch
    {
        [HarmonyPrefix]
        public static void Prefix(BattleSimpleActionUI_Dice __instance, BattleDiceBehavior b)
        {
            MusicDiceVisuals.PrepareAction(__instance, b?.card?.card, b?.behaviourInCard);
        }
    }

    [HarmonyPatch(typeof(BattleSimpleActionUI_Dice), "SetColors")]
    public static class BattleSimpleActionUI_Dice_SetColors_MusicStyle_Patch
    {
        [HarmonyPostfix]
        public static void Postfix(BattleSimpleActionUI_Dice __instance)
        {
            MusicDiceVisuals.ApplyOnActionDice(__instance);
        }
    }

    [HarmonyPatch(typeof(BattleDiceCardUI), nameof(BattleDiceCardUI.SetCard))]
    public static class BattleDiceCardUI_SetCard_MusicStyle_Patch
    {
        [HarmonyPrefix]
        public static void Prefix(BattleDiceCardUI __instance)
        {
            MusicDiceVisuals.RestoreCardBeforeBind(__instance);
        }

        [HarmonyPostfix]
        public static void Postfix(BattleDiceCardUI __instance)
        {
            try
            {
                MusicDiceVisuals.ApplyOnCardUI(__instance);
                PhantomDreamCardVisuals.ApplyOnCardUI(__instance);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Card UI visual patch error: {ex}");
            }
        }
    }

    [HarmonyPatch(typeof(BattleDiceCardUI), nameof(BattleDiceCardUI.SetPreviewResist))]
    public static class BattleDiceCardUI_SetPreviewResist_MusicStyle_Patch
    {
        [HarmonyPostfix]
        public static void Postfix(BattleDiceCardUI __instance)
        {
            try
            {
                MusicDiceVisuals.ApplyOnCardUI(__instance);
                PhantomDreamCardVisuals.ApplyOnCardUI(__instance);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Card UI preview resist visual patch error: {ex}");
            }
        }
    }

    [HarmonyPatch(typeof(BattleUnitCardsInHandUI), nameof(BattleUnitCardsInHandUI.UpdateCardList))]
    public static class BattleUnitCardsInHandUI_UpdateCardList_SteriaCardVisuals_Patch
    {
        [HarmonyPostfix]
        public static void Postfix(BattleUnitCardsInHandUI __instance)
        {
            try
            {
                List<BattleDiceCardUI> cards = __instance?.GetCardUIList();
                if (cards == null)
                {
                    return;
                }

                foreach (BattleDiceCardUI cardUi in cards)
                {
                    MusicDiceVisuals.ApplyOnCardUI(cardUi);
                    PhantomDreamCardVisuals.ApplyOnCardUI(cardUi);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Hand card visual refresh patch error: {ex}");
            }
        }
    }

    [HarmonyPatch(typeof(BattleDiceCard_BehaviourDescUI), "SetBehaviourInfo")]
    public static class BattleDiceCard_BehaviourDescUI_SetBehaviourInfo_MusicStyle_Patch
    {
        [HarmonyPrefix]
        public static void Prefix(BattleDiceCard_BehaviourDescUI __instance)
        {
            MusicDiceVisuals.RestoreBeforeBind(__instance);
        }

        [HarmonyPostfix]
        public static void Postfix(BattleDiceCard_BehaviourDescUI __instance, DiceBehaviour behaviour, LorId cardId, List<DiceBehaviour> behaviourList, bool isHide)
        {
            try
            {
                if (__instance == null || isHide)
                {
                    return;
                }

                MusicDiceVisuals.ApplyOnDescUI(__instance, cardId, behaviour);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music dice behaviour desc patch error: {ex}");
            }
        }
    }

    internal static class ChristashaCounterDestroySupport
    {
        public static void TryForceDestroy(BattleDiceBehavior behavior, string source)
        {
            try
            {
                if (behavior == null || behavior.Type != BehaviourType.Standby)
                {
                    return;
                }

                bool isTargetCounter = behavior.abilityList != null &&
                                       behavior.abilityList.Exists(a => a is global::DiceCardAbility_ChristashaEgoDestroyDice);
                if (!isTargetCounter)
                {
                    return;
                }

                BattlePlayingCardDataInUnitModel card = behavior.card;
                if (card != null)
                {
                    List<BattleDiceBehavior> list = card.GetDiceBehaviorList();
                    int index = list?.IndexOf(behavior) ?? -1;
                    if (index >= 0)
                    {
                        card.DestroyDice(match => match.index == index);
                        SteriaLogger.Log($"CounterDestroyPatch: destroy by resolved index={index}, source={source}, cardHash={card.GetHashCode()}");
                    }
                    else
                    {
                        SteriaLogger.Log($"CounterDestroyPatch: skip destroy because index resolve failed, source={source}, behaviorIndex={behavior.Index}, cardHash={card.GetHashCode()}");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] CounterDestroyPatch error ({source}): {ex}");
            }
        }
    }

    [HarmonyPatch(typeof(BattlePlayingCardDataInUnitModel), nameof(BattlePlayingCardDataInUnitModel.OnWinParryingDefense))]
    public static class BattlePlayingCardDataInUnitModel_OnWinParryingDefense_ChristashaCounterDestroyPatch
    {
        [HarmonyPostfix]
        public static void Postfix(BattlePlayingCardDataInUnitModel __instance)
        {
            ChristashaCounterDestroySupport.TryForceDestroy(__instance?.currentBehavior, "OnWinParryingDefense");
        }
    }

    [HarmonyPatch(typeof(BattlePlayingCardDataInUnitModel), nameof(BattlePlayingCardDataInUnitModel.OnWinParryingAttack))]
    public static class BattlePlayingCardDataInUnitModel_OnWinParryingAttack_ChristashaCounterDestroyPatch
    {
        [HarmonyPostfix]
        public static void Postfix(BattlePlayingCardDataInUnitModel __instance)
        {
            ChristashaCounterDestroySupport.TryForceDestroy(__instance?.currentBehavior, "OnWinParryingAttack");
        }
    }

    [HarmonyPatch(typeof(BattlePlayingCardDataInUnitModel), nameof(BattlePlayingCardDataInUnitModel.OnSucceedAttack))]
    public static class BattlePlayingCardDataInUnitModel_OnSucceedAttack_ChristashaCounterDestroyPatch
    {
        [HarmonyPostfix]
        public static void Postfix(BattleDiceBehavior behavior)
        {
            ChristashaCounterDestroySupport.TryForceDestroy(behavior, "OnSucceedAttack");
        }
    }

    [HarmonyPatch(typeof(BattlePlayingCardDataInUnitModel), nameof(BattlePlayingCardDataInUnitModel.OnDefenseWithoutParryingWin))]
    public static class BattlePlayingCardDataInUnitModel_OnDefenseWithoutParryingWin_ChristashaCounterDestroyPatch
    {
        [HarmonyPostfix]
        public static void Postfix(BattlePlayingCardDataInUnitModel __instance)
        {
            ChristashaCounterDestroySupport.TryForceDestroy(__instance?.currentBehavior, "OnDefenseWithoutParryingWin");
        }
    }

    [HarmonyPatch(typeof(BattleDiceCard_BehaviourDescUI), "SetBehaviourInfo")]
    public static class BattleDiceCard_BehaviourDescUI_SetBehaviourInfo_DynamicRange_Patch
    {
        [HarmonyPostfix]
        public static void Postfix(BattleDiceCard_BehaviourDescUI __instance, DiceBehaviour behaviour, LorId cardId, List<DiceBehaviour> behaviourList, bool isHide)
        {
            try
            {
                if (__instance == null || isHide || behaviour == null || behaviour.Min == 999)
                {
                    return;
                }

                BattleDiceCardUI cardUi = __instance.GetComponentInParent<BattleDiceCardUI>();
                BattleDiceCardModel cardModel = cardUi?.CardModel;
                if (cardModel == null)
                {
                    return;
                }

                if (!DiceRangePreviewHelper.TryGetAdjustedRange(cardModel, behaviour, out int min, out int max))
                {
                    return;
                }

                if (__instance.txt_range != null)
                {
                    __instance.txt_range.text = $"{min}-{max}";
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Dynamic dice range patch error: {ex}");
            }
        }
    }

    // --- 乐章型骰子：非战斗界面（卡组/图鉴）样式 ---
    [HarmonyPatch(typeof(UI.UIOriginCardSlot), "SetData")]
    public static class UIOriginCardSlot_SetData_MusicStyle_Patch
    {
        [HarmonyPrefix]
        public static void Prefix(UI.UIOriginCardSlot __instance)
        {
            MusicDiceVisuals.RestoreBeforeBind(__instance);
        }

        [HarmonyPostfix]
        public static void Postfix(UI.UIOriginCardSlot __instance, DiceCardItemModel cardmodel)
        {
            try
            {
                MusicDiceVisuals.ApplyOnOriginSlot(__instance, cardmodel);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music dice origin card slot patch error: {ex}");
            }
        }
    }

    [HarmonyPatch(typeof(UI.UIDetailCardDescSlot), "SetBehaviourInfo")]
    public static class UIDetailCardDescSlot_SetBehaviourInfo_MusicStyle_Patch
    {
        [HarmonyPrefix]
        public static void Prefix(UI.UIDetailCardDescSlot __instance)
        {
            MusicDiceVisuals.RestoreBeforeBind(__instance);
        }

        [HarmonyPostfix]
        public static void Postfix(UI.UIDetailCardDescSlot __instance, DiceBehaviour behaviour, LorId cardId, List<DiceBehaviour> behaviourList, bool isHide)
        {
            try
            {
                if (__instance == null || isHide)
                {
                    return;
                }

                MusicDiceVisuals.ApplyOnDetailDescSlot(__instance, cardId, behaviour);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] Music dice detail desc patch error: {ex}");
            }
        }
    }

    // --- 烧伤伤害Hook：触发日光混乱伤害 + Phase2最大生命值削减 ---
    [HarmonyPatch(typeof(BattleUnitBuf_burn), nameof(BattleUnitBuf_burn.OnRoundEnd))]
    public static class BurnDamage_Postfix_Patch
    {
        public class BurnRoundState
        {
            public BattleUnitModel owner;
            public int hpBefore;
            public int burnStackBefore;
        }

        public static void Prefix(BattleUnitBuf_burn __instance, out BurnRoundState __state)
        {
            __state = null;
            try
            {
                var ownerField = typeof(BattleUnitBuf).GetField("_owner",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (ownerField == null) return;
                BattleUnitModel owner = ownerField.GetValue(__instance) as BattleUnitModel;
                if (owner != null)
                {
                    __state = new BurnRoundState
                    {
                        owner = owner,
                        hpBefore = (int)owner.hp,
                        burnStackBefore = Math.Max(0, __instance?.stack ?? 0)
                    };
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] BurnDamage Prefix error: {ex.Message}");
            }
        }

        public static void Postfix(BattleUnitBuf_burn __instance, BurnRoundState __state)
        {
            try
            {
                if (__state == null || __state.owner == null)
                {
                    return;
                }

                BattleUnitModel owner = __state.owner;
                if (owner.IsDead())
                {
                    return;
                }

                int hpAfter = (int)owner.hp;
                int burnDamage = Math.Max(0, __state.hpBefore - hpAfter);

                // 兜底：部分情况下HP差值可能取不到，使用烧伤层数作为触发值
                int effectiveBurnDamage = burnDamage > 0 ? burnDamage : __state.burnStackBefore;
                if (effectiveBurnDamage <= 0)
                {
                    return;
                }

                SteriaLogger.Log($"烧伤结算捕获: {owner.UnitData?.unitData?.name} HP {__state.hpBefore}->{hpAfter}, burnStackBefore={__state.burnStackBefore}, effective={effectiveBurnDamage}");

                // 触发日光 + Phase2最大生命值削减
                PassiveAbility_9010003.OnAnyUnitBurnDamage(owner, effectiveBurnDamage);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Steria] BurnDamage Postfix error: {ex.Message}");
            }
        }
    }

    // --- 扩展 CardAbilityHelper 以支持流x2 ---
    public static class FlowMultiplierHelper
    {
        /// <summary>
        /// 添加流层数，考虑流x2被动
        /// </summary>
        public static void AddFlowStacksWithMultiplier(BattleUnitModel owner, int amount)
        {
            CardAbilityHelper.AddFlowStacks(owner, amount, true);
        }
    }
} // End of Steria namespace
