// Ocean-current art uses the common native-anchored texture playback contract.
public abstract class DiceAttackEffect_Steria_OceanCurrentBase : DiceAttackEffect_Steria_AnhierTextureBase
{
    protected override string AssetDirectoryName { get { return "OceanCurrentTextureCombat"; } }
}

public sealed class DiceAttackEffect_Steria_OceanCurrentSlash : DiceAttackEffect_Steria_OceanCurrentBase
{ protected override string ProfileName { get { return "CurrentSlash"; } } protected override ActionDetail PivotAction { get { return ActionDetail.Slash; } } }
public sealed class DiceAttackEffect_Steria_OceanCurrentHit : DiceAttackEffect_Steria_OceanCurrentBase
{ protected override string ProfileName { get { return "CurrentHit"; } } protected override ActionDetail PivotAction { get { return ActionDetail.Hit; } } }
public sealed class DiceAttackEffect_Steria_OceanCurrentPierce : DiceAttackEffect_Steria_OceanCurrentBase
{ protected override string ProfileName { get { return "CurrentPierce"; } } protected override ActionDetail PivotAction { get { return ActionDetail.Penetrate; } } }
public sealed class DiceAttackEffect_Steria_OceanCurrentGuard : DiceAttackEffect_Steria_OceanCurrentBase
{ protected override string ProfileName { get { return "CurrentGuard"; } } protected override ActionDetail PivotAction { get { return ActionDetail.Guard; } } }
public sealed class DiceAttackEffect_Steria_OceanCurrentFarHit : DiceAttackEffect_Steria_OceanCurrentBase
{ protected override string ProfileName { get { return "CurrentFarHit"; } } protected override ActionDetail PivotAction { get { return ActionDetail.Fire; } } }
